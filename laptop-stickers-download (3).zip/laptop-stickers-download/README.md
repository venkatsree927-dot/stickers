# Laptop Stickers Download — Sticker Studio

A responsive sticker gallery with 62 downloadable SVG designs and paid printed sticker sets. Each paid set contains 6 designs from one category for ₹399. Delivery is restricted to India (6-digit PIN code required).

## Website preview
You can open `index.html` directly to browse the sticker gallery and download SVGs. For the order workflow, run the included server as described below.

## Manual UPI order workflow
This project includes a starter backend for this workflow:
1. Customer enters their name, email, phone, one category, exactly 6 sticker titles from that category, quantity, and Indian delivery address.
2. The server creates an order with status `pending_payment_verification` and stores it in a private local JSON file.
3. Customer pays by scanning your UPI QR. You must manually check the payment in your UPI/bank app.
4. Store owner opens `/admin`, enters the admin password, reviews the order and transaction reference, then clicks **Verify payment & send email**.
5. The order is marked paid and an order confirmation email is sent using your configured SMTP email service.

**The UPI QR image has not been provided yet.** Once you supply it, save it in this folder as `upi-qr.png` (or update the image filename in `index.html`). Until then, checkout displays a placeholder.

## Run locally
1. Install Node.js (LTS).
2. Open a terminal in this folder and run `npm install`.
3. Copy `.env.example` to `.env` and fill in a strong unique `ADMIN_PASSWORD` and your SMTP details. Do not share or publish `.env`.
4. Run `npm start`.
5. Open `http://localhost:3000` for the shop and `http://localhost:3000/admin` for order administration.

## Email setup
You need an email provider that supports SMTP. Put its SMTP host, port, username, password/app password, and sender email in `.env`. The server sends the confirmation email only after the admin verifies payment. If email sending fails, the order remains marked paid and the admin page lets you retry sending the email after fixing SMTP settings.

## Before public launch — important
- This is a starter implementation, not a managed/hosted store. It must be deployed to a server that supports Node.js, persistent storage, and HTTPS. A static host alone cannot run the order backend.
- The included JSON file is suitable for local testing only; for a public store, use a persistent database and backups, add rate limiting, CSRF/security hardening, and a stronger admin authentication system.
- Keep `.env`, `data/orders.json`, and all customer information private. Never use customer-submitted payment screenshots alone as proof of payment; verify in your UPI/bank account.
- The order form validates a six-digit Indian PIN code, but you should verify delivery address and shipping fees before dispatch. The ₹399 set price does not yet specify whether delivery is included.
- The website currently does not include your actual UPI QR because you have not uploaded it yet.

## Design collections
- 8 everyday/cute designs
- 12 football-themed designs
- 20 original TV-show-inspired typography/decorative designs
- 22 Formula 1 driver-themed designs

The F1 and entertainment designs are fan-themed original artwork, not official team/series merchandise. Review intellectual-property rights and commercial-use permissions before selling them.
