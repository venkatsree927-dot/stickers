const filters = document.querySelectorAll('.category-pill');
const cards = [...document.querySelectorAll('.design-card')];
const searchInput = document.getElementById('searchInput');
const resultsCount = document.getElementById('resultsCount');
const emptyState = document.getElementById('emptyState');
const grid = document.getElementById('stickerGrid');
let activeFilter = 'all';

function updateGallery() {
  const query = searchInput.value.trim().toLowerCase();
  let visible = 0;
  cards.forEach(card => {
    const categories = card.dataset.category.split(' ');
    const matchesFilter = activeFilter === 'all' || categories.includes(activeFilter);
    const matchesQuery = card.dataset.name.includes(query) || card.querySelector('h3').textContent.toLowerCase().includes(query);
    const show = matchesFilter && matchesQuery;
    card.hidden = !show;
    if (show) visible++;
  });
  resultsCount.textContent = `${visible} design${visible === 1 ? '' : 's'}`;
  emptyState.hidden = visible !== 0;
  grid.style.display = visible ? 'grid' : 'none';
}
filters.forEach(button => button.addEventListener('click', () => {
  filters.forEach(item => item.classList.toggle('active', item === button));
  activeFilter = button.dataset.filter;
  updateGallery();
}));
searchInput.addEventListener('input', updateGallery);
document.getElementById('year').textContent = new Date().getFullYear();

const svgDesigns = {
  'good-vibes.svg': `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="600" viewBox="0 0 600 600"><rect width="600" height="600" fill="none"/><g transform="translate(300 300)"><g stroke="#d9a83b" stroke-width="10" stroke-linecap="round">${Array.from({length:12},(_,i)=>`<path d="M0 -190 V-220" transform="rotate(${i*30})"/>`).join('')}</g><circle r="170" fill="#f3cd5f" stroke="#fff" stroke-width="12"/><text x="0" y="-5" font-family="Arial,sans-serif" font-size="78" font-weight="900" text-anchor="middle" fill="#34352d">GOOD</text><text x="0" y="78" font-family="Arial,sans-serif" font-size="78" font-weight="900" text-anchor="middle" fill="#34352d">VIBES</text><path d="M90 -100 l8 17 19 2 -14 13 4 19 -17 -10 -17 10 4 -19 -14 -13 19 -2z" fill="#fff8dd"/></g></svg>`,
  'happy-flower.svg': `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="600" viewBox="0 0 600 600"><rect width="600" height="600" fill="none"/><g transform="translate(300 290)" fill="#d96f83" stroke="#fff" stroke-width="8">${Array.from({length:8},(_,i)=>`<ellipse cx="0" cy="-105" rx="58" ry="100" transform="rotate(${i*45})"/>`).join('')}<circle r="70" fill="#f4cd66"/><circle cx="-23" cy="-5" r="7" fill="#543f42" stroke="none"/><circle cx="23" cy="-5" r="7" fill="#543f42" stroke="none"/><path d="M-20 20 Q0 42 20 20" fill="none" stroke="#543f42" stroke-width="7" stroke-linecap="round"/></g><path d="M300 390 Q265 455 220 460 M300 410 Q350 450 380 435" fill="none" stroke="#769b70" stroke-width="13" stroke-linecap="round"/><path d="M240 450 Q180 410 195 380 Q250 390 240 450 M355 442 Q410 400 430 425 Q400 470 355 442" fill="#8eaf85"/></svg>`,
  'stay-curious.svg': `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="600" viewBox="0 0 600 600"><rect width="600" height="600" fill="none"/><ellipse cx="300" cy="300" rx="220" ry="82" fill="none" stroke="#edab80" stroke-width="28" transform="rotate(-25 300 300)"/><circle cx="300" cy="300" r="140" fill="#557b90" stroke="#fff" stroke-width="12"/><text x="300" y="292" font-family="Arial,sans-serif" font-size="52" font-weight="800" text-anchor="middle" fill="#fff">stay</text><text x="300" y="350" font-family="Arial,sans-serif" font-size="52" font-weight="800" text-anchor="middle" fill="#fff">curious</text><path d="M385 175 l10 22 24 3 -18 16 5 24 -21 -12 -21 12 5 -24 -18 -16 24 -3z" fill="#f5d66d"/></svg>`,
  'choose-kindness.svg': `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="600" viewBox="0 0 600 600"><rect width="600" height="600" fill="none"/><path d="M300 455 C245 405 105 305 145 205 C177 125 265 145 300 205 C335 145 423 125 455 205 C495 305 355 405 300 455Z" fill="#e99083" stroke="#fff" stroke-width="12"/><text x="300" y="280" font-family="Arial,sans-serif" font-size="46" font-weight="900" text-anchor="middle" fill="#fff">choose</text><text x="300" y="335" font-family="Arial,sans-serif" font-size="46" font-weight="900" text-anchor="middle" fill="#fff">kindness</text></svg>`,
  'tiny-happy.svg': `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="600" viewBox="0 0 600 600"><rect width="600" height="600" fill="none"/><circle cx="300" cy="300" r="190" fill="#f3d56f" stroke="#fff" stroke-width="14"/><circle cx="235" cy="265" r="16" fill="#3f4b39"/><circle cx="365" cy="265" r="16" fill="#3f4b39"/><path d="M220 335 Q300 425 380 335" fill="none" stroke="#3f4b39" stroke-width="17" stroke-linecap="round"/><path d="M430 105 l12 27 29 3 -22 19 6 28 -25 -15 -25 15 6 -28 -22 -19 29 -3z" fill="#e78d75"/></svg>`,
  'room-for-magic.svg': `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="600" viewBox="0 0 600 600"><rect width="600" height="600" fill="none"/><g fill="#8e73aa"><path d="M130 130 l13 30 33 4 -25 22 7 32 -28 -17 -28 17 7 -32 -25 -22 33 -4z"/><path d="M445 135 l8 19 21 2 -16 14 5 20 -18 -11 -18 11 4 -20 -15 -14 21 -2z"/></g><text x="300" y="280" font-family="Arial,sans-serif" font-size="57" font-weight="800" text-anchor="middle" fill="#67537d">make room</text><text x="300" y="355" font-family="Georgia,serif" font-size="78" font-style="italic" text-anchor="middle" fill="#67537d">for magic</text><path d="M190 400 Q300 430 410 400" fill="none" stroke="#d7a7df" stroke-width="7" stroke-linecap="round"/></svg>`,
  'offline-mode.svg': `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="600" viewBox="0 0 600 600"><rect width="600" height="600" fill="none"/><g fill="#6f9a80"><rect x="180" y="140" width="26" height="60" rx="13"/><rect x="220" y="115" width="26" height="85" rx="13"/><rect x="260" y="155" width="26" height="45" rx="13"/></g><text x="300" y="300" font-family="Arial,sans-serif" font-size="76" font-weight="900" text-anchor="middle" fill="#3e6a51">OFFLINE</text><text x="300" y="380" font-family="Georgia,serif" font-size="90" font-style="italic" text-anchor="middle" fill="#3e6a51">mode</text><path d="M175 425 Q300 455 425 425" fill="none" stroke="#93b59a" stroke-width="8" stroke-linecap="round"/></svg>`,
  'little-lucky.svg': `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="600" viewBox="0 0 600 600"><rect width="600" height="600" fill="none"/><path d="M300 85 L350 220 L495 225 L380 315 L420 460 L300 375 L180 460 L220 315 L105 225 L250 220Z" fill="#efc65d" stroke="#fff" stroke-width="12" stroke-linejoin="round"/><text x="300" y="275" font-family="Arial,sans-serif" font-size="58" text-anchor="middle" fill="#45687c">little</text><text x="300" y="345" font-family="Arial,sans-serif" font-size="76" font-weight="900" text-anchor="middle" fill="#45687c">lucky</text></svg>`,
  'cr7-legend.svg': `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="600" viewBox="0 0 600 600"><rect width="600" height="600" rx="42" fill="#f3e7d8"/><circle cx="510" cy="95" r="72" fill="#d84c43" opacity=".2"/><circle cx="85" cy="510" r="105" fill="#d84c43" opacity=".15"/><path d="M268 120 Q300 90 331 120 L350 164 335 192 350 222 390 250 423 332 380 350 349 286 347 384 380 470 337 482 298 410 267 482 224 470 253 384 251 286 220 350 177 332 210 250 250 222 265 192 250 164Z" fill="#172b3a"/><path d="M257 133 Q300 102 342 133 L330 178 269 178Z" fill="#d84c43"/><text x="300" y="440" text-anchor="middle" font-family="Arial,sans-serif" font-size="105" font-weight="900" letter-spacing="-4" fill="#d84c43" stroke="#f3e7d8" stroke-width="4" paint-order="stroke">7</text><text x="300" y="510" text-anchor="middle" font-family="Arial,sans-serif" font-size="44" font-weight="900" letter-spacing="-1.5" fill="#172b3a">CR7 LEGEND</text><text x="300" y="550" text-anchor="middle" font-family="Arial,sans-serif" font-size="18" font-weight="700" letter-spacing="3" fill="#172b3a" opacity=".72">THE NO. 7 SPIRIT</text></svg>`,
  'siuuu-energy.svg': `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="600" viewBox="0 0 600 600"><rect width="600" height="600" rx="42" fill="#f4d86b"/><circle cx="510" cy="95" r="72" fill="#e84c3d" opacity=".2"/><circle cx="85" cy="510" r="105" fill="#e84c3d" opacity=".15"/><path d="M300 120l24 53 58 7-43 39 12 57-51-29-51 29 12-57-43-39 58-7z" fill="#e84c3d"/><path d="M170 290l13 28 31 4-23 21 6 30-27-16-27 16 6-30-23-21 31-4z M425 320l11 24 27 3-20 18 5 26-23-13-23 13 5-26-20-18 27-3z" fill="#e84c3d"/><text x="300" y="510" text-anchor="middle" font-family="Arial,sans-serif" font-size="44" font-weight="900" letter-spacing="-1.5" fill="#20251f">SIUUU!</text><text x="300" y="550" text-anchor="middle" font-family="Arial,sans-serif" font-size="18" font-weight="700" letter-spacing="3" fill="#20251f" opacity=".72">CELEBRATE EVERY WIN</text></svg>`,
  'number-seven.svg': `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="600" viewBox="0 0 600 600"><rect width="600" height="600" rx="42" fill="#e6edf0"/><circle cx="510" cy="95" r="72" fill="#d84c43" opacity=".2"/><circle cx="85" cy="510" r="105" fill="#d84c43" opacity=".15"/><path d="M235 145l-86 43 43 90 50-22v175h116V256l50 22 43-90-86-43-30 35h-70z" fill="#d84c43" stroke="#183b55" stroke-width="10" stroke-linejoin="round"/><text x="300" y="330" text-anchor="middle" font-family="Arial,sans-serif" font-size="100" font-weight="900" fill="#183b55">7</text><text x="300" y="510" text-anchor="middle" font-family="Arial,sans-serif" font-size="44" font-weight="900" letter-spacing="-1.5" fill="#183b55">NUMBER</text><text x="300" y="550" text-anchor="middle" font-family="Arial,sans-serif" font-size="18" font-weight="700" letter-spacing="3" fill="#183b55" opacity=".72">BUILT DIFFERENT</text></svg>`,
  'portugal-pride.svg': `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="600" viewBox="0 0 600 600"><rect width="600" height="600" rx="42" fill="#f4e6d8"/><circle cx="510" cy="95" r="72" fill="#c7433c" opacity=".2"/><circle cx="85" cy="510" r="105" fill="#c7433c" opacity=".15"/><path d="M145 155h75v290h-75z M262 155h75v290h-75z M379 155h75v290h-75z" fill="#c7433c"/><path d="M130 145h340v310H130z" fill="none" stroke="#174c3a" stroke-width="12" rx="20"/><circle cx="300" cy="300" r="75" fill="#f4e6d8" stroke="#174c3a" stroke-width="10"/><text x="300" y="328" text-anchor="middle" font-family="Arial,sans-serif" font-size="74" font-weight="900" fill="#174c3a">7</text><text x="300" y="510" text-anchor="middle" font-family="Arial,sans-serif" font-size="44" font-weight="900" letter-spacing="-1.5" fill="#174c3a">PORTUGAL</text><text x="300" y="550" text-anchor="middle" font-family="Arial,sans-serif" font-size="18" font-weight="700" letter-spacing="3" fill="#174c3a" opacity=".72">MATCH DAY MODE</text></svg>`,
  'ronaldo-silhouette.svg': `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="600" viewBox="0 0 600 600"><rect width="600" height="600" rx="42" fill="#dbe8ee"/><circle cx="510" cy="95" r="72" fill="#d9a743" opacity=".2"/><circle cx="85" cy="510" r="105" fill="#d9a743" opacity=".15"/><path d="M268 120 Q300 90 331 120 L350 164 335 192 350 222 390 250 423 332 380 350 349 286 347 384 380 470 337 482 298 410 267 482 224 470 253 384 251 286 220 350 177 332 210 250 250 222 265 192 250 164Z" fill="#183b55"/><path d="M257 133 Q300 102 342 133 L330 178 269 178Z" fill="#d9a743"/><text x="300" y="510" text-anchor="middle" font-family="Arial,sans-serif" font-size="44" font-weight="900" letter-spacing="-1.5" fill="#183b55">THE STRIKER</text><text x="300" y="550" text-anchor="middle" font-family="Arial,sans-serif" font-size="18" font-weight="700" letter-spacing="3" fill="#183b55" opacity=".72">FOCUS • FIRE • FINISH</text></svg>`,
  'never-give-up.svg': `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="600" viewBox="0 0 600 600"><rect width="600" height="600" rx="42" fill="#e6eadb"/><circle cx="510" cy="95" r="72" fill="#e3b83e" opacity=".2"/><circle cx="85" cy="510" r="105" fill="#e3b83e" opacity=".15"/><path d="M300 120l24 53 58 7-43 39 12 57-51-29-51 29 12-57-43-39 58-7z" fill="#e3b83e"/><path d="M170 290l13 28 31 4-23 21 6 30-27-16-27 16 6-30-23-21 31-4z M425 320l11 24 27 3-20 18 5 26-23-13-23 13 5-26-20-18 27-3z" fill="#e3b83e"/><text x="300" y="440" text-anchor="middle" font-family="Arial,sans-serif" font-size="105" font-weight="900" letter-spacing="-4" fill="#e3b83e" stroke="#e6eadb" stroke-width="4" paint-order="stroke">7</text><text x="300" y="510" text-anchor="middle" font-family="Arial,sans-serif" font-size="44" font-weight="900" letter-spacing="-1.5" fill="#26372d">NEVER QUIT</text><text x="300" y="550" text-anchor="middle" font-family="Arial,sans-serif" font-size="18" font-weight="700" letter-spacing="3" fill="#26372d" opacity=".72">ONE MORE REP</text></svg>`,
  'messi-magic.svg': `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="600" viewBox="0 0 600 600"><rect width="600" height="600" rx="42" fill="#e4f0f5"/><circle cx="510" cy="95" r="72" fill="#67a9d1" opacity=".2"/><circle cx="85" cy="510" r="105" fill="#67a9d1" opacity=".15"/><path d="M268 120 Q300 90 331 120 L350 164 335 192 350 222 390 250 423 332 380 350 349 286 347 384 380 470 337 482 298 410 267 482 224 470 253 384 251 286 220 350 177 332 210 250 250 222 265 192 250 164Z" fill="#173e60"/><path d="M257 133 Q300 102 342 133 L330 178 269 178Z" fill="#67a9d1"/><text x="300" y="440" text-anchor="middle" font-family="Arial,sans-serif" font-size="105" font-weight="900" letter-spacing="-4" fill="#67a9d1" stroke="#e4f0f5" stroke-width="4" paint-order="stroke">10</text><text x="300" y="510" text-anchor="middle" font-family="Arial,sans-serif" font-size="44" font-weight="900" letter-spacing="-1.5" fill="#173e60">MESSI MAGIC</text><text x="300" y="550" text-anchor="middle" font-family="Arial,sans-serif" font-size="18" font-weight="700" letter-spacing="3" fill="#173e60" opacity=".72">PURE FOOTBALL JOY</text></svg>`,
  'm10-goat.svg': `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="600" viewBox="0 0 600 600"><rect width="600" height="600" rx="42" fill="#f4e8d8"/><circle cx="510" cy="95" r="72" fill="#d5b14e" opacity=".2"/><circle cx="85" cy="510" r="105" fill="#d5b14e" opacity=".15"/><path d="M235 145l-86 43 43 90 50-22v175h116V256l50 22 43-90-86-43-30 35h-70z" fill="#d5b14e" stroke="#193d5b" stroke-width="10" stroke-linejoin="round"/><text x="300" y="330" text-anchor="middle" font-family="Arial,sans-serif" font-size="100" font-weight="900" fill="#193d5b">10</text><text x="300" y="510" text-anchor="middle" font-family="Arial,sans-serif" font-size="44" font-weight="900" letter-spacing="-1.5" fill="#193d5b">M10</text><text x="300" y="550" text-anchor="middle" font-family="Arial,sans-serif" font-size="18" font-weight="700" letter-spacing="3" fill="#193d5b" opacity=".72">GOAT MODE: ON</text></svg>`,
  'argentina-dream.svg': `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="600" viewBox="0 0 600 600"><rect width="600" height="600" rx="42" fill="#e3f0f4"/><circle cx="510" cy="95" r="72" fill="#78bce0" opacity=".2"/><circle cx="85" cy="510" r="105" fill="#78bce0" opacity=".15"/><path d="M145 155h75v290h-75z M262 155h75v290h-75z M379 155h75v290h-75z" fill="#78bce0"/><path d="M130 145h340v310H130z" fill="none" stroke="#194b70" stroke-width="12" rx="20"/><circle cx="300" cy="300" r="75" fill="#e3f0f4" stroke="#194b70" stroke-width="10"/><text x="300" y="328" text-anchor="middle" font-family="Arial,sans-serif" font-size="74" font-weight="900" fill="#194b70">10</text><text x="300" y="510" text-anchor="middle" font-family="Arial,sans-serif" font-size="44" font-weight="900" letter-spacing="-1.5" fill="#194b70">ARGENTINA</text><text x="300" y="550" text-anchor="middle" font-family="Arial,sans-serif" font-size="18" font-weight="700" letter-spacing="3" fill="#194b70" opacity=".72">DREAM • BELIEVE • PLAY</text></svg>`,
  'the-playmaker.svg': `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="600" viewBox="0 0 600 600"><rect width="600" height="600" rx="42" fill="#e9e1f0"/><circle cx="510" cy="95" r="72" fill="#8a72ae" opacity=".2"/><circle cx="85" cy="510" r="105" fill="#8a72ae" opacity=".15"/><path d="M268 120 Q300 90 331 120 L350 164 335 192 350 222 390 250 423 332 380 350 349 286 347 384 380 470 337 482 298 410 267 482 224 470 253 384 251 286 220 350 177 332 210 250 250 222 265 192 250 164Z" fill="#372c50"/><path d="M257 133 Q300 102 342 133 L330 178 269 178Z" fill="#8a72ae"/><text x="300" y="440" text-anchor="middle" font-family="Arial,sans-serif" font-size="105" font-weight="900" letter-spacing="-4" fill="#8a72ae" stroke="#e9e1f0" stroke-width="4" paint-order="stroke">10</text><text x="300" y="510" text-anchor="middle" font-family="Arial,sans-serif" font-size="44" font-weight="900" letter-spacing="-1.5" fill="#372c50">THE PLAYMAKER</text><text x="300" y="550" text-anchor="middle" font-family="Arial,sans-serif" font-size="18" font-weight="700" letter-spacing="3" fill="#372c50" opacity=".72">VISION MAKES MAGIC</text></svg>`,
  'football-is-life.svg': `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="600" viewBox="0 0 600 600"><rect width="600" height="600" rx="42" fill="#e6eddb"/><circle cx="510" cy="95" r="72" fill="#78a56b" opacity=".2"/><circle cx="85" cy="510" r="105" fill="#78a56b" opacity=".15"/><circle cx="300" cy="235" r="110" fill="#fff" stroke="#20372b" stroke-width="12"/><path d="M300 176l47 34-18 55h-58l-18-55z M300 125l-42 30 15 21 M347 210l49-7 12 43-43 19 M271 265l-39 42 30 34 47-16 M329 265l39 42-17 45-47-16 M253 210l-49-7-12 43 43 19" fill="#20372b" stroke="#20372b" stroke-width="5" stroke-linejoin="round"/><text x="300" y="510" text-anchor="middle" font-family="Arial,sans-serif" font-size="44" font-weight="900" letter-spacing="-1.5" fill="#20372b">FOOTBALL</text><text x="300" y="550" text-anchor="middle" font-family="Arial,sans-serif" font-size="18" font-weight="700" letter-spacing="3" fill="#20372b" opacity=".72">IS MORE THAN A GAME</text></svg>`,
  'goat-debate.svg': `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="600" viewBox="0 0 600 600"><rect width="600" height="600" rx="42" fill="#f0e5d8"/><circle cx="510" cy="95" r="72" fill="#d7a84a" opacity=".2"/><circle cx="85" cy="510" r="105" fill="#d7a84a" opacity=".15"/><path d="M300 360C260 320 150 250 180 190c24-48 82-38 120 10 38-48 96-58 120-10 30 60-80 130-120 170Z" fill="#d7a84a" stroke="#28384b" stroke-width="8"/><circle cx="300" cy="235" r="47" fill="#f0e5d8" stroke="#28384b" stroke-width="7"/><path d="M300 211l18 13-7 21h-22l-7-21z" fill="#28384b"/><text x="300" y="510" text-anchor="middle" font-family="Arial,sans-serif" font-size="44" font-weight="900" letter-spacing="-1.5" fill="#28384b">GOAT DEBATE</text><text x="300" y="550" text-anchor="middle" font-family="Arial,sans-serif" font-size="18" font-weight="700" letter-spacing="3" fill="#28384b" opacity=".72">TWO ICONS • ONE GAME</text></svg>`,
  'himym-suit-up.svg': `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="600" viewBox="0 0 600 600">
  <rect x="22" y="22" width="556" height="556" rx="48" fill="#e9d8c5" stroke="#392d2a" stroke-width="8"/>
  <circle cx="300" cy="240" r="164" fill="none" stroke="#392d2a" stroke-width="3" opacity=".22"/>
  <circle cx="300" cy="240" r="135" fill="none" stroke="#392d2a" stroke-width="2" stroke-dasharray="5 14" opacity=".45"/>
  <path d="M100 125l12 27 30 3-22 20 6 29-26-15-26 15 6-29-22-20 30-3z M485 150l9 20 22 2-16 15 4 22-19-11-19 11 4-22-16-15 22-2z M120 350l8 18 20 2-15 13 4 20-17-10-18 10 4-20-15-13 20-2z" fill="#392d2a" opacity=".85"/>
  <text x="300" y="205" text-anchor="middle" font-family="Arial,sans-serif" font-size="28" font-weight="800" letter-spacing="4" fill="#392d2a">HOW I MET YOUR MOTHER</text>
  <text x="300" y="270" text-anchor="middle" font-family="Arial,sans-serif" font-size="45" font-weight="900" letter-spacing="1" fill="#392d2a">SUIT UP</text>
  <path d="M180 315 Q300 350 420 315" fill="none" stroke="#392d2a" stroke-width="5" stroke-linecap="round" opacity=".65"/>
  <text x="300" y="400" text-anchor="middle" font-family="Georgia,serif" font-size="27" font-style="italic" fill="#392d2a">Suit Up</text>
  <text x="300" y="490" text-anchor="middle" font-family="Arial,sans-serif" font-size="19" font-weight="700" letter-spacing="4" fill="#392d2a" opacity=".78">FAN-MADE • ORIGINAL ART</text>
  <text x="300" y="535" text-anchor="middle" font-family="Arial,sans-serif" font-size="15" letter-spacing="3" fill="#392d2a" opacity=".65">STICKER STUDIO</text>
</svg>`,
  'himym-yellow-umbrella.svg': `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="600" viewBox="0 0 600 600">
  <rect x="22" y="22" width="556" height="556" rx="48" fill="#f4dc59" stroke="#384e67" stroke-width="8"/>
  <circle cx="300" cy="240" r="164" fill="none" stroke="#384e67" stroke-width="3" opacity=".22"/>
  <circle cx="300" cy="240" r="135" fill="none" stroke="#384e67" stroke-width="2" stroke-dasharray="5 14" opacity=".45"/>
  <path d="M100 125l12 27 30 3-22 20 6 29-26-15-26 15 6-29-22-20 30-3z M485 150l9 20 22 2-16 15 4 22-19-11-19 11 4-22-16-15 22-2z M120 350l8 18 20 2-15 13 4 20-17-10-18 10 4-20-15-13 20-2z" fill="#384e67" opacity=".85"/>
  <text x="300" y="205" text-anchor="middle" font-family="Arial,sans-serif" font-size="28" font-weight="800" letter-spacing="4" fill="#384e67">HOW I MET YOUR MOTHER</text>
  <text x="300" y="270" text-anchor="middle" font-family="Arial,sans-serif" font-size="45" font-weight="900" letter-spacing="1" fill="#384e67">YELLOW UMBRELLA</text>
  <path d="M180 315 Q300 350 420 315" fill="none" stroke="#384e67" stroke-width="5" stroke-linecap="round" opacity=".65"/>
  <text x="300" y="400" text-anchor="middle" font-family="Georgia,serif" font-size="27" font-style="italic" fill="#384e67">Yellow Umbrella</text>
  <text x="300" y="490" text-anchor="middle" font-family="Arial,sans-serif" font-size="19" font-weight="700" letter-spacing="4" fill="#384e67" opacity=".78">FAN-MADE • ORIGINAL ART</text>
  <text x="300" y="535" text-anchor="middle" font-family="Arial,sans-serif" font-size="15" letter-spacing="3" fill="#384e67" opacity=".65">STICKER STUDIO</text>
</svg>`,
  'friends-central-perk.svg': `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="600" viewBox="0 0 600 600">
  <rect x="22" y="22" width="556" height="556" rx="48" fill="#c9dfc8" stroke="#3c664b" stroke-width="8"/>
  <circle cx="300" cy="240" r="164" fill="none" stroke="#3c664b" stroke-width="3" opacity=".22"/>
  <circle cx="300" cy="240" r="135" fill="none" stroke="#3c664b" stroke-width="2" stroke-dasharray="5 14" opacity=".45"/>
  <path d="M100 125l12 27 30 3-22 20 6 29-26-15-26 15 6-29-22-20 30-3z M485 150l9 20 22 2-16 15 4 22-19-11-19 11 4-22-16-15 22-2z M120 350l8 18 20 2-15 13 4 20-17-10-18 10 4-20-15-13 20-2z" fill="#3c664b" opacity=".85"/>
  <text x="300" y="205" text-anchor="middle" font-family="Arial,sans-serif" font-size="28" font-weight="800" letter-spacing="4" fill="#3c664b">FRIENDS</text>
  <text x="300" y="270" text-anchor="middle" font-family="Arial,sans-serif" font-size="36" font-weight="900" letter-spacing="1" fill="#3c664b">COFFEE & FRIENDS</text>
  <path d="M180 315 Q300 350 420 315" fill="none" stroke="#3c664b" stroke-width="5" stroke-linecap="round" opacity=".65"/>
  <text x="300" y="400" text-anchor="middle" font-family="Georgia,serif" font-size="27" font-style="italic" fill="#3c664b">Coffee &amp; Friends</text>
  <text x="300" y="490" text-anchor="middle" font-family="Arial,sans-serif" font-size="19" font-weight="700" letter-spacing="4" fill="#3c664b" opacity=".78">FAN-MADE • ORIGINAL ART</text>
  <text x="300" y="535" text-anchor="middle" font-family="Arial,sans-serif" font-size="15" letter-spacing="3" fill="#3c664b" opacity=".65">STICKER STUDIO</text>
</svg>`,
  'friends-the-one.svg': `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="600" viewBox="0 0 600 600">
  <rect x="22" y="22" width="556" height="556" rx="48" fill="#e8d8f1" stroke="#694d7c" stroke-width="8"/>
  <circle cx="300" cy="240" r="164" fill="none" stroke="#694d7c" stroke-width="3" opacity=".22"/>
  <circle cx="300" cy="240" r="135" fill="none" stroke="#694d7c" stroke-width="2" stroke-dasharray="5 14" opacity=".45"/>
  <path d="M100 125l12 27 30 3-22 20 6 29-26-15-26 15 6-29-22-20 30-3z M485 150l9 20 22 2-16 15 4 22-19-11-19 11 4-22-16-15 22-2z M120 350l8 18 20 2-15 13 4 20-17-10-18 10 4-20-15-13 20-2z" fill="#694d7c" opacity=".85"/>
  <text x="300" y="205" text-anchor="middle" font-family="Arial,sans-serif" font-size="28" font-weight="800" letter-spacing="4" fill="#694d7c">FRIENDS</text>
  <text x="300" y="270" text-anchor="middle" font-family="Arial,sans-serif" font-size="45" font-weight="900" letter-spacing="1" fill="#694d7c">THE ONE WITH...</text>
  <path d="M180 315 Q300 350 420 315" fill="none" stroke="#694d7c" stroke-width="5" stroke-linecap="round" opacity=".65"/>
  <text x="300" y="400" text-anchor="middle" font-family="Georgia,serif" font-size="27" font-style="italic" fill="#694d7c">The One With...</text>
  <text x="300" y="490" text-anchor="middle" font-family="Arial,sans-serif" font-size="19" font-weight="700" letter-spacing="4" fill="#694d7c" opacity=".78">FAN-MADE • ORIGINAL ART</text>
  <text x="300" y="535" text-anchor="middle" font-family="Arial,sans-serif" font-size="15" letter-spacing="3" fill="#694d7c" opacity=".65">STICKER STUDIO</text>
</svg>`,
  'modern-family-chaos.svg': `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="600" viewBox="0 0 600 600">
  <rect x="22" y="22" width="556" height="556" rx="48" fill="#f2d8b9" stroke="#744d38" stroke-width="8"/>
  <circle cx="300" cy="240" r="164" fill="none" stroke="#744d38" stroke-width="3" opacity=".22"/>
  <circle cx="300" cy="240" r="135" fill="none" stroke="#744d38" stroke-width="2" stroke-dasharray="5 14" opacity=".45"/>
  <path d="M100 125l12 27 30 3-22 20 6 29-26-15-26 15 6-29-22-20 30-3z M485 150l9 20 22 2-16 15 4 22-19-11-19 11 4-22-16-15 22-2z M120 350l8 18 20 2-15 13 4 20-17-10-18 10 4-20-15-13 20-2z" fill="#744d38" opacity=".85"/>
  <text x="300" y="205" text-anchor="middle" font-family="Arial,sans-serif" font-size="28" font-weight="800" letter-spacing="4" fill="#744d38">MODERN FAMILY</text>
  <text x="300" y="270" text-anchor="middle" font-family="Arial,sans-serif" font-size="45" font-weight="900" letter-spacing="1" fill="#744d38">FAMILY CHAOS</text>
  <path d="M180 315 Q300 350 420 315" fill="none" stroke="#744d38" stroke-width="5" stroke-linecap="round" opacity=".65"/>
  <text x="300" y="400" text-anchor="middle" font-family="Georgia,serif" font-size="27" font-style="italic" fill="#744d38">Family Chaos Club</text>
  <text x="300" y="490" text-anchor="middle" font-family="Arial,sans-serif" font-size="19" font-weight="700" letter-spacing="4" fill="#744d38" opacity=".78">FAN-MADE • ORIGINAL ART</text>
  <text x="300" y="535" text-anchor="middle" font-family="Arial,sans-serif" font-size="15" letter-spacing="3" fill="#744d38" opacity=".65">STICKER STUDIO</text>
</svg>`,
  'modern-family-together.svg': `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="600" viewBox="0 0 600 600">
  <rect x="22" y="22" width="556" height="556" rx="48" fill="#d5e7e7" stroke="#315d65" stroke-width="8"/>
  <circle cx="300" cy="240" r="164" fill="none" stroke="#315d65" stroke-width="3" opacity=".22"/>
  <circle cx="300" cy="240" r="135" fill="none" stroke="#315d65" stroke-width="2" stroke-dasharray="5 14" opacity=".45"/>
  <path d="M100 125l12 27 30 3-22 20 6 29-26-15-26 15 6-29-22-20 30-3z M485 150l9 20 22 2-16 15 4 22-19-11-19 11 4-22-16-15 22-2z M120 350l8 18 20 2-15 13 4 20-17-10-18 10 4-20-15-13 20-2z" fill="#315d65" opacity=".85"/>
  <text x="300" y="205" text-anchor="middle" font-family="Arial,sans-serif" font-size="28" font-weight="800" letter-spacing="4" fill="#315d65">MODERN FAMILY</text>
  <text x="300" y="270" text-anchor="middle" font-family="Arial,sans-serif" font-size="36" font-weight="900" letter-spacing="1" fill="#315d65">DIFFERENT TOGETHER</text>
  <path d="M180 315 Q300 350 420 315" fill="none" stroke="#315d65" stroke-width="5" stroke-linecap="round" opacity=".65"/>
  <text x="300" y="400" text-anchor="middle" font-family="Georgia,serif" font-size="27" font-style="italic" fill="#315d65">Different Together</text>
  <text x="300" y="490" text-anchor="middle" font-family="Arial,sans-serif" font-size="19" font-weight="700" letter-spacing="4" fill="#315d65" opacity=".78">FAN-MADE • ORIGINAL ART</text>
  <text x="300" y="535" text-anchor="middle" font-family="Arial,sans-serif" font-size="15" letter-spacing="3" fill="#315d65" opacity=".65">STICKER STUDIO</text>
</svg>`,
  'big-bang-nerd-mode.svg': `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="600" viewBox="0 0 600 600">
  <rect x="22" y="22" width="556" height="556" rx="48" fill="#d7e2f7" stroke="#344a7b" stroke-width="8"/>
  <circle cx="300" cy="240" r="164" fill="none" stroke="#344a7b" stroke-width="3" opacity=".22"/>
  <circle cx="300" cy="240" r="135" fill="none" stroke="#344a7b" stroke-width="2" stroke-dasharray="5 14" opacity=".45"/>
  <path d="M100 125l12 27 30 3-22 20 6 29-26-15-26 15 6-29-22-20 30-3z M485 150l9 20 22 2-16 15 4 22-19-11-19 11 4-22-16-15 22-2z M120 350l8 18 20 2-15 13 4 20-17-10-18 10 4-20-15-13 20-2z" fill="#344a7b" opacity=".85"/>
  <text x="300" y="205" text-anchor="middle" font-family="Arial,sans-serif" font-size="28" font-weight="800" letter-spacing="4" fill="#344a7b">BIG BANG THEORY</text>
  <text x="300" y="270" text-anchor="middle" font-family="Arial,sans-serif" font-size="45" font-weight="900" letter-spacing="1" fill="#344a7b">NERD MODE</text>
  <path d="M180 315 Q300 350 420 315" fill="none" stroke="#344a7b" stroke-width="5" stroke-linecap="round" opacity=".65"/>
  <text x="300" y="400" text-anchor="middle" font-family="Georgia,serif" font-size="27" font-style="italic" fill="#344a7b">Nerd Mode</text>
  <text x="300" y="490" text-anchor="middle" font-family="Arial,sans-serif" font-size="19" font-weight="700" letter-spacing="4" fill="#344a7b" opacity=".78">FAN-MADE • ORIGINAL ART</text>
  <text x="300" y="535" text-anchor="middle" font-family="Arial,sans-serif" font-size="15" letter-spacing="3" fill="#344a7b" opacity=".65">STICKER STUDIO</text>
</svg>`,
  'big-bang-geek-chic.svg': `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="600" viewBox="0 0 600 600">
  <rect x="22" y="22" width="556" height="556" rx="48" fill="#f3d5a9" stroke="#6f4b2c" stroke-width="8"/>
  <circle cx="300" cy="240" r="164" fill="none" stroke="#6f4b2c" stroke-width="3" opacity=".22"/>
  <circle cx="300" cy="240" r="135" fill="none" stroke="#6f4b2c" stroke-width="2" stroke-dasharray="5 14" opacity=".45"/>
  <path d="M100 125l12 27 30 3-22 20 6 29-26-15-26 15 6-29-22-20 30-3z M485 150l9 20 22 2-16 15 4 22-19-11-19 11 4-22-16-15 22-2z M120 350l8 18 20 2-15 13 4 20-17-10-18 10 4-20-15-13 20-2z" fill="#6f4b2c" opacity=".85"/>
  <text x="300" y="205" text-anchor="middle" font-family="Arial,sans-serif" font-size="28" font-weight="800" letter-spacing="4" fill="#6f4b2c">BIG BANG THEORY</text>
  <text x="300" y="270" text-anchor="middle" font-family="Arial,sans-serif" font-size="45" font-weight="900" letter-spacing="1" fill="#6f4b2c">GEEK CHIC</text>
  <path d="M180 315 Q300 350 420 315" fill="none" stroke="#6f4b2c" stroke-width="5" stroke-linecap="round" opacity=".65"/>
  <text x="300" y="400" text-anchor="middle" font-family="Georgia,serif" font-size="27" font-style="italic" fill="#6f4b2c">Geek Chic</text>
  <text x="300" y="490" text-anchor="middle" font-family="Arial,sans-serif" font-size="19" font-weight="700" letter-spacing="4" fill="#6f4b2c" opacity=".78">FAN-MADE • ORIGINAL ART</text>
  <text x="300" y="535" text-anchor="middle" font-family="Arial,sans-serif" font-size="15" letter-spacing="3" fill="#6f4b2c" opacity=".65">STICKER STUDIO</text>
</svg>`,
  'office-worlds-okayest.svg': `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="600" viewBox="0 0 600 600">
  <rect x="22" y="22" width="556" height="556" rx="48" fill="#d6e5d1" stroke="#375c42" stroke-width="8"/>
  <circle cx="300" cy="240" r="164" fill="none" stroke="#375c42" stroke-width="3" opacity=".22"/>
  <circle cx="300" cy="240" r="135" fill="none" stroke="#375c42" stroke-width="2" stroke-dasharray="5 14" opacity=".45"/>
  <path d="M100 125l12 27 30 3-22 20 6 29-26-15-26 15 6-29-22-20 30-3z M485 150l9 20 22 2-16 15 4 22-19-11-19 11 4-22-16-15 22-2z M120 350l8 18 20 2-15 13 4 20-17-10-18 10 4-20-15-13 20-2z" fill="#375c42" opacity=".85"/>
  <text x="300" y="205" text-anchor="middle" font-family="Arial,sans-serif" font-size="28" font-weight="800" letter-spacing="4" fill="#375c42">OFFICE</text>
  <text x="300" y="270" text-anchor="middle" font-family="Arial,sans-serif" font-size="45" font-weight="900" letter-spacing="1" fill="#375c42">OKAYEST BOSS</text>
  <path d="M180 315 Q300 350 420 315" fill="none" stroke="#375c42" stroke-width="5" stroke-linecap="round" opacity=".65"/>
  <text x="300" y="400" text-anchor="middle" font-family="Georgia,serif" font-size="27" font-style="italic" fill="#375c42">World&apos;s Okayest Boss</text>
  <text x="300" y="490" text-anchor="middle" font-family="Arial,sans-serif" font-size="19" font-weight="700" letter-spacing="4" fill="#375c42" opacity=".78">FAN-MADE • ORIGINAL ART</text>
  <text x="300" y="535" text-anchor="middle" font-family="Arial,sans-serif" font-size="15" letter-spacing="3" fill="#375c42" opacity=".65">STICKER STUDIO</text>
</svg>`,
  'office-paper-company.svg': `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="600" viewBox="0 0 600 600">
  <rect x="22" y="22" width="556" height="556" rx="48" fill="#e9e3d5" stroke="#49483e" stroke-width="8"/>
  <circle cx="300" cy="240" r="164" fill="none" stroke="#49483e" stroke-width="3" opacity=".22"/>
  <circle cx="300" cy="240" r="135" fill="none" stroke="#49483e" stroke-width="2" stroke-dasharray="5 14" opacity=".45"/>
  <path d="M100 125l12 27 30 3-22 20 6 29-26-15-26 15 6-29-22-20 30-3z M485 150l9 20 22 2-16 15 4 22-19-11-19 11 4-22-16-15 22-2z M120 350l8 18 20 2-15 13 4 20-17-10-18 10 4-20-15-13 20-2z" fill="#49483e" opacity=".85"/>
  <text x="300" y="205" text-anchor="middle" font-family="Arial,sans-serif" font-size="28" font-weight="800" letter-spacing="4" fill="#49483e">OFFICE</text>
  <text x="300" y="270" text-anchor="middle" font-family="Arial,sans-serif" font-size="45" font-weight="900" letter-spacing="1" fill="#49483e">PAPER COMPANY</text>
  <path d="M180 315 Q300 350 420 315" fill="none" stroke="#49483e" stroke-width="5" stroke-linecap="round" opacity=".65"/>
  <text x="300" y="400" text-anchor="middle" font-family="Georgia,serif" font-size="27" font-style="italic" fill="#49483e">Paper Company Energy</text>
  <text x="300" y="490" text-anchor="middle" font-family="Arial,sans-serif" font-size="19" font-weight="700" letter-spacing="4" fill="#49483e" opacity=".78">FAN-MADE • ORIGINAL ART</text>
  <text x="300" y="535" text-anchor="middle" font-family="Arial,sans-serif" font-size="15" letter-spacing="3" fill="#49483e" opacity=".65">STICKER STUDIO</text>
</svg>`,
  'outer-banks-pogue-life.svg': `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="600" viewBox="0 0 600 600">
  <rect x="22" y="22" width="556" height="556" rx="48" fill="#c7e5e6" stroke="#245e68" stroke-width="8"/>
  <circle cx="300" cy="240" r="164" fill="none" stroke="#245e68" stroke-width="3" opacity=".22"/>
  <circle cx="300" cy="240" r="135" fill="none" stroke="#245e68" stroke-width="2" stroke-dasharray="5 14" opacity=".45"/>
  <path d="M100 125l12 27 30 3-22 20 6 29-26-15-26 15 6-29-22-20 30-3z M485 150l9 20 22 2-16 15 4 22-19-11-19 11 4-22-16-15 22-2z M120 350l8 18 20 2-15 13 4 20-17-10-18 10 4-20-15-13 20-2z" fill="#245e68" opacity=".85"/>
  <text x="300" y="205" text-anchor="middle" font-family="Arial,sans-serif" font-size="28" font-weight="800" letter-spacing="4" fill="#245e68">OUTER BANKS</text>
  <text x="300" y="270" text-anchor="middle" font-family="Arial,sans-serif" font-size="45" font-weight="900" letter-spacing="1" fill="#245e68">POGUE LIFE</text>
  <path d="M180 315 Q300 350 420 315" fill="none" stroke="#245e68" stroke-width="5" stroke-linecap="round" opacity=".65"/>
  <text x="300" y="400" text-anchor="middle" font-family="Georgia,serif" font-size="27" font-style="italic" fill="#245e68">Pogue Life</text>
  <text x="300" y="490" text-anchor="middle" font-family="Arial,sans-serif" font-size="19" font-weight="700" letter-spacing="4" fill="#245e68" opacity=".78">FAN-MADE • ORIGINAL ART</text>
  <text x="300" y="535" text-anchor="middle" font-family="Arial,sans-serif" font-size="15" letter-spacing="3" fill="#245e68" opacity=".65">STICKER STUDIO</text>
</svg>`,
  'outer-banks-treasure.svg': `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="600" viewBox="0 0 600 600">
  <rect x="22" y="22" width="556" height="556" rx="48" fill="#efd7b0" stroke="#76512f" stroke-width="8"/>
  <circle cx="300" cy="240" r="164" fill="none" stroke="#76512f" stroke-width="3" opacity=".22"/>
  <circle cx="300" cy="240" r="135" fill="none" stroke="#76512f" stroke-width="2" stroke-dasharray="5 14" opacity=".45"/>
  <path d="M100 125l12 27 30 3-22 20 6 29-26-15-26 15 6-29-22-20 30-3z M485 150l9 20 22 2-16 15 4 22-19-11-19 11 4-22-16-15 22-2z M120 350l8 18 20 2-15 13 4 20-17-10-18 10 4-20-15-13 20-2z" fill="#76512f" opacity=".85"/>
  <text x="300" y="205" text-anchor="middle" font-family="Arial,sans-serif" font-size="28" font-weight="800" letter-spacing="4" fill="#76512f">OUTER BANKS</text>
  <text x="300" y="270" text-anchor="middle" font-family="Arial,sans-serif" font-size="45" font-weight="900" letter-spacing="1" fill="#76512f">TREASURE COAST</text>
  <path d="M180 315 Q300 350 420 315" fill="none" stroke="#76512f" stroke-width="5" stroke-linecap="round" opacity=".65"/>
  <text x="300" y="400" text-anchor="middle" font-family="Georgia,serif" font-size="27" font-style="italic" fill="#76512f">Treasure Coast</text>
  <text x="300" y="490" text-anchor="middle" font-family="Arial,sans-serif" font-size="19" font-weight="700" letter-spacing="4" fill="#76512f" opacity=".78">FAN-MADE • ORIGINAL ART</text>
  <text x="300" y="535" text-anchor="middle" font-family="Arial,sans-serif" font-size="15" letter-spacing="3" fill="#76512f" opacity=".65">STICKER STUDIO</text>
</svg>`,
  'wednesday-dark-academia.svg': `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="600" viewBox="0 0 600 600">
  <rect x="22" y="22" width="556" height="556" rx="48" fill="#d8d5df" stroke="#34303f" stroke-width="8"/>
  <circle cx="300" cy="240" r="164" fill="none" stroke="#34303f" stroke-width="3" opacity=".22"/>
  <circle cx="300" cy="240" r="135" fill="none" stroke="#34303f" stroke-width="2" stroke-dasharray="5 14" opacity=".45"/>
  <path d="M100 125l12 27 30 3-22 20 6 29-26-15-26 15 6-29-22-20 30-3z M485 150l9 20 22 2-16 15 4 22-19-11-19 11 4-22-16-15 22-2z M120 350l8 18 20 2-15 13 4 20-17-10-18 10 4-20-15-13 20-2z" fill="#34303f" opacity=".85"/>
  <text x="300" y="205" text-anchor="middle" font-family="Arial,sans-serif" font-size="28" font-weight="800" letter-spacing="4" fill="#34303f">WEDNESDAY</text>
  <text x="300" y="270" text-anchor="middle" font-family="Arial,sans-serif" font-size="45" font-weight="900" letter-spacing="1" fill="#34303f">DARK ACADEMIA</text>
  <path d="M180 315 Q300 350 420 315" fill="none" stroke="#34303f" stroke-width="5" stroke-linecap="round" opacity=".65"/>
  <text x="300" y="400" text-anchor="middle" font-family="Georgia,serif" font-size="27" font-style="italic" fill="#34303f">Dark Academia</text>
  <text x="300" y="490" text-anchor="middle" font-family="Arial,sans-serif" font-size="19" font-weight="700" letter-spacing="4" fill="#34303f" opacity=".78">FAN-MADE • ORIGINAL ART</text>
  <text x="300" y="535" text-anchor="middle" font-family="Arial,sans-serif" font-size="15" letter-spacing="3" fill="#34303f" opacity=".65">STICKER STUDIO</text>
</svg>`,
  'wednesday-nevermore.svg': `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="600" viewBox="0 0 600 600">
  <rect x="22" y="22" width="556" height="556" rx="48" fill="#e4e0e8" stroke="#3d3448" stroke-width="8"/>
  <circle cx="300" cy="240" r="164" fill="none" stroke="#3d3448" stroke-width="3" opacity=".22"/>
  <circle cx="300" cy="240" r="135" fill="none" stroke="#3d3448" stroke-width="2" stroke-dasharray="5 14" opacity=".45"/>
  <path d="M100 125l12 27 30 3-22 20 6 29-26-15-26 15 6-29-22-20 30-3z M485 150l9 20 22 2-16 15 4 22-19-11-19 11 4-22-16-15 22-2z M120 350l8 18 20 2-15 13 4 20-17-10-18 10 4-20-15-13 20-2z" fill="#3d3448" opacity=".85"/>
  <text x="300" y="205" text-anchor="middle" font-family="Arial,sans-serif" font-size="28" font-weight="800" letter-spacing="4" fill="#3d3448">WEDNESDAY</text>
  <text x="300" y="270" text-anchor="middle" font-family="Arial,sans-serif" font-size="45" font-weight="900" letter-spacing="1" fill="#3d3448">NEVERMORE MOOD</text>
  <path d="M180 315 Q300 350 420 315" fill="none" stroke="#3d3448" stroke-width="5" stroke-linecap="round" opacity=".65"/>
  <text x="300" y="400" text-anchor="middle" font-family="Georgia,serif" font-size="27" font-style="italic" fill="#3d3448">Nevermore Mood</text>
  <text x="300" y="490" text-anchor="middle" font-family="Arial,sans-serif" font-size="19" font-weight="700" letter-spacing="4" fill="#3d3448" opacity=".78">FAN-MADE • ORIGINAL ART</text>
  <text x="300" y="535" text-anchor="middle" font-family="Arial,sans-serif" font-size="15" letter-spacing="3" fill="#3d3448" opacity=".65">STICKER STUDIO</text>
</svg>`,
  'stranger-things-upside-down.svg': `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="600" viewBox="0 0 600 600">
  <rect x="22" y="22" width="556" height="556" rx="48" fill="#202b38" stroke="#f05a50" stroke-width="8"/>
  <circle cx="300" cy="240" r="164" fill="none" stroke="#f05a50" stroke-width="3" opacity=".22"/>
  <circle cx="300" cy="240" r="135" fill="none" stroke="#f05a50" stroke-width="2" stroke-dasharray="5 14" opacity=".45"/>
  <path d="M100 125l12 27 30 3-22 20 6 29-26-15-26 15 6-29-22-20 30-3z M485 150l9 20 22 2-16 15 4 22-19-11-19 11 4-22-16-15 22-2z M120 350l8 18 20 2-15 13 4 20-17-10-18 10 4-20-15-13 20-2z" fill="#f05a50" opacity=".85"/>
  <text x="300" y="205" text-anchor="middle" font-family="Arial,sans-serif" font-size="28" font-weight="800" letter-spacing="4" fill="#f05a50">STRANGER THINGS</text>
  <text x="300" y="270" text-anchor="middle" font-family="Arial,sans-serif" font-size="45" font-weight="900" letter-spacing="1" fill="#f05a50">UPSIDE DOWN</text>
  <path d="M180 315 Q300 350 420 315" fill="none" stroke="#f05a50" stroke-width="5" stroke-linecap="round" opacity=".65"/>
  <text x="300" y="400" text-anchor="middle" font-family="Georgia,serif" font-size="27" font-style="italic" fill="#f05a50">Upside Down Club</text>
  <text x="300" y="490" text-anchor="middle" font-family="Arial,sans-serif" font-size="19" font-weight="700" letter-spacing="4" fill="#f05a50" opacity=".78">FAN-MADE • ORIGINAL ART</text>
  <text x="300" y="535" text-anchor="middle" font-family="Arial,sans-serif" font-size="15" letter-spacing="3" fill="#f05a50" opacity=".65">STICKER STUDIO</text>
</svg>`,
  'stranger-things-night-lights.svg': `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="600" viewBox="0 0 600 600">
  <rect x="22" y="22" width="556" height="556" rx="48" fill="#d5e3e8" stroke="#263d55" stroke-width="8"/>
  <circle cx="300" cy="240" r="164" fill="none" stroke="#263d55" stroke-width="3" opacity=".22"/>
  <circle cx="300" cy="240" r="135" fill="none" stroke="#263d55" stroke-width="2" stroke-dasharray="5 14" opacity=".45"/>
  <path d="M100 125l12 27 30 3-22 20 6 29-26-15-26 15 6-29-22-20 30-3z M485 150l9 20 22 2-16 15 4 22-19-11-19 11 4-22-16-15 22-2z M120 350l8 18 20 2-15 13 4 20-17-10-18 10 4-20-15-13 20-2z" fill="#263d55" opacity=".85"/>
  <text x="300" y="205" text-anchor="middle" font-family="Arial,sans-serif" font-size="28" font-weight="800" letter-spacing="4" fill="#263d55">STRANGER THINGS</text>
  <text x="300" y="270" text-anchor="middle" font-family="Arial,sans-serif" font-size="45" font-weight="900" letter-spacing="1" fill="#263d55">NIGHT LIGHTS</text>
  <path d="M180 315 Q300 350 420 315" fill="none" stroke="#263d55" stroke-width="5" stroke-linecap="round" opacity=".65"/>
  <text x="300" y="400" text-anchor="middle" font-family="Georgia,serif" font-size="27" font-style="italic" fill="#263d55">Night Lights</text>
  <text x="300" y="490" text-anchor="middle" font-family="Arial,sans-serif" font-size="19" font-weight="700" letter-spacing="4" fill="#263d55" opacity=".78">FAN-MADE • ORIGINAL ART</text>
  <text x="300" y="535" text-anchor="middle" font-family="Arial,sans-serif" font-size="15" letter-spacing="3" fill="#263d55" opacity=".65">STICKER STUDIO</text>
</svg>`,
  'b99-nine-nine.svg': `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="600" viewBox="0 0 600 600">
  <rect x="22" y="22" width="556" height="556" rx="48" fill="#cbdff0" stroke="#234e7a" stroke-width="8"/>
  <circle cx="300" cy="240" r="164" fill="none" stroke="#234e7a" stroke-width="3" opacity=".22"/>
  <circle cx="300" cy="240" r="135" fill="none" stroke="#234e7a" stroke-width="2" stroke-dasharray="5 14" opacity=".45"/>
  <path d="M100 125l12 27 30 3-22 20 6 29-26-15-26 15 6-29-22-20 30-3z M485 150l9 20 22 2-16 15 4 22-19-11-19 11 4-22-16-15 22-2z M120 350l8 18 20 2-15 13 4 20-17-10-18 10 4-20-15-13 20-2z" fill="#234e7a" opacity=".85"/>
  <text x="300" y="205" text-anchor="middle" font-family="Arial,sans-serif" font-size="28" font-weight="800" letter-spacing="4" fill="#234e7a">BROOKLYN NINE-NINE</text>
  <text x="300" y="270" text-anchor="middle" font-family="Arial,sans-serif" font-size="45" font-weight="900" letter-spacing="1" fill="#234e7a">NINE-NINE!</text>
  <path d="M180 315 Q300 350 420 315" fill="none" stroke="#234e7a" stroke-width="5" stroke-linecap="round" opacity=".65"/>
  <text x="300" y="400" text-anchor="middle" font-family="Georgia,serif" font-size="27" font-style="italic" fill="#234e7a">Nine-Nine!</text>
  <text x="300" y="490" text-anchor="middle" font-family="Arial,sans-serif" font-size="19" font-weight="700" letter-spacing="4" fill="#234e7a" opacity=".78">FAN-MADE • ORIGINAL ART</text>
  <text x="300" y="535" text-anchor="middle" font-family="Arial,sans-serif" font-size="15" letter-spacing="3" fill="#234e7a" opacity=".65">STICKER STUDIO</text>
</svg>`,
  'b99-cool-cool.svg': `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="600" viewBox="0 0 600 600">
  <rect x="22" y="22" width="556" height="556" rx="48" fill="#f2d6c7" stroke="#784c3c" stroke-width="8"/>
  <circle cx="300" cy="240" r="164" fill="none" stroke="#784c3c" stroke-width="3" opacity=".22"/>
  <circle cx="300" cy="240" r="135" fill="none" stroke="#784c3c" stroke-width="2" stroke-dasharray="5 14" opacity=".45"/>
  <path d="M100 125l12 27 30 3-22 20 6 29-26-15-26 15 6-29-22-20 30-3z M485 150l9 20 22 2-16 15 4 22-19-11-19 11 4-22-16-15 22-2z M120 350l8 18 20 2-15 13 4 20-17-10-18 10 4-20-15-13 20-2z" fill="#784c3c" opacity=".85"/>
  <text x="300" y="205" text-anchor="middle" font-family="Arial,sans-serif" font-size="28" font-weight="800" letter-spacing="4" fill="#784c3c">BROOKLYN NINE-NINE</text>
  <text x="300" y="270" text-anchor="middle" font-family="Arial,sans-serif" font-size="45" font-weight="900" letter-spacing="1" fill="#784c3c">COOL COOL COOL</text>
  <path d="M180 315 Q300 350 420 315" fill="none" stroke="#784c3c" stroke-width="5" stroke-linecap="round" opacity=".65"/>
  <text x="300" y="400" text-anchor="middle" font-family="Georgia,serif" font-size="27" font-style="italic" fill="#784c3c">Cool Cool Cool</text>
  <text x="300" y="490" text-anchor="middle" font-family="Arial,sans-serif" font-size="19" font-weight="700" letter-spacing="4" fill="#784c3c" opacity=".78">FAN-MADE • ORIGINAL ART</text>
  <text x="300" y="535" text-anchor="middle" font-family="Arial,sans-serif" font-size="15" letter-spacing="3" fill="#784c3c" opacity=".65">STICKER STUDIO</text>
</svg>`,
  'vampire-diaries-mystic-falls.svg': `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="600" viewBox="0 0 600 600">
  <rect x="22" y="22" width="556" height="556" rx="48" fill="#d5d4e9" stroke="#393456" stroke-width="8"/>
  <circle cx="300" cy="240" r="164" fill="none" stroke="#393456" stroke-width="3" opacity=".22"/>
  <circle cx="300" cy="240" r="135" fill="none" stroke="#393456" stroke-width="2" stroke-dasharray="5 14" opacity=".45"/>
  <path d="M100 125l12 27 30 3-22 20 6 29-26-15-26 15 6-29-22-20 30-3z M485 150l9 20 22 2-16 15 4 22-19-11-19 11 4-22-16-15 22-2z M120 350l8 18 20 2-15 13 4 20-17-10-18 10 4-20-15-13 20-2z" fill="#393456" opacity=".85"/>
  <text x="300" y="205" text-anchor="middle" font-family="Arial,sans-serif" font-size="28" font-weight="800" letter-spacing="4" fill="#393456">VAMPIRE DIARIES</text>
  <text x="300" y="270" text-anchor="middle" font-family="Arial,sans-serif" font-size="45" font-weight="900" letter-spacing="1" fill="#393456">MYSTIC FALLS</text>
  <path d="M180 315 Q300 350 420 315" fill="none" stroke="#393456" stroke-width="5" stroke-linecap="round" opacity=".65"/>
  <text x="300" y="400" text-anchor="middle" font-family="Georgia,serif" font-size="27" font-style="italic" fill="#393456">Mystic Falls After Dark</text>
  <text x="300" y="490" text-anchor="middle" font-family="Arial,sans-serif" font-size="19" font-weight="700" letter-spacing="4" fill="#393456" opacity=".78">FAN-MADE • ORIGINAL ART</text>
  <text x="300" y="535" text-anchor="middle" font-family="Arial,sans-serif" font-size="15" letter-spacing="3" fill="#393456" opacity=".65">STICKER STUDIO</text>
</svg>`,
  'vampire-diaries-midnight.svg': `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="600" viewBox="0 0 600 600">
  <rect x="22" y="22" width="556" height="556" rx="48" fill="#e9d5df" stroke="#68384d" stroke-width="8"/>
  <circle cx="300" cy="240" r="164" fill="none" stroke="#68384d" stroke-width="3" opacity=".22"/>
  <circle cx="300" cy="240" r="135" fill="none" stroke="#68384d" stroke-width="2" stroke-dasharray="5 14" opacity=".45"/>
  <path d="M100 125l12 27 30 3-22 20 6 29-26-15-26 15 6-29-22-20 30-3z M485 150l9 20 22 2-16 15 4 22-19-11-19 11 4-22-16-15 22-2z M120 350l8 18 20 2-15 13 4 20-17-10-18 10 4-20-15-13 20-2z" fill="#68384d" opacity=".85"/>
  <text x="300" y="205" text-anchor="middle" font-family="Arial,sans-serif" font-size="28" font-weight="800" letter-spacing="4" fill="#68384d">VAMPIRE DIARIES</text>
  <text x="300" y="270" text-anchor="middle" font-family="Arial,sans-serif" font-size="36" font-weight="900" letter-spacing="1" fill="#68384d">MIDNIGHT DIARIES</text>
  <path d="M180 315 Q300 350 420 315" fill="none" stroke="#68384d" stroke-width="5" stroke-linecap="round" opacity=".65"/>
  <text x="300" y="400" text-anchor="middle" font-family="Georgia,serif" font-size="27" font-style="italic" fill="#68384d">Midnight Diaries</text>
  <text x="300" y="490" text-anchor="middle" font-family="Arial,sans-serif" font-size="19" font-weight="700" letter-spacing="4" fill="#68384d" opacity=".78">FAN-MADE • ORIGINAL ART</text>
  <text x="300" y="535" text-anchor="middle" font-family="Arial,sans-serif" font-size="15" letter-spacing="3" fill="#68384d" opacity=".65">STICKER STUDIO</text>
</svg>`,
  'f1-george-russell.svg': `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="600" viewBox="0 0 600 600"><rect x="18" y="18" width="564" height="564" rx="52" fill="#f8f6f0" stroke="#00a19b" stroke-width="10"/><path d="M85 150 L515 150 L470 220 L130 220Z" fill="#00a19b" opacity=".13"/><path d="M100 260 L500 260" stroke="#00a19b" stroke-width="8" stroke-linecap="round" opacity=".5"/><circle cx="300" cy="205" r="72" fill="#00a19b" opacity=".12"/><path d="M260 165 L340 165 L365 195 L340 225 L260 225 L235 195Z" fill="#00a19b"/><path d="M275 174 L325 174 L339 194 L325 214 L275 214 L261 194Z" fill="#f8f6f0" opacity=".9"/><path d="M130 465 L470 465" stroke="#00a19b" stroke-width="5" stroke-linecap="round" opacity=".45"/><text x="300" y="385" text-anchor="middle" font-family="Arial,sans-serif" font-size="43" font-weight="900" letter-spacing="1" fill="#00a19b">GEORGE RUSSELL</text><text x="300" y="500" text-anchor="middle" font-family="Arial,sans-serif" font-size="24" font-weight="800" letter-spacing="5" fill="#00a19b">RACE WEEKEND</text><text x="300" y="540" text-anchor="middle" font-family="Arial,sans-serif" font-size="16" font-weight="700" letter-spacing="4" fill="#00a19b" opacity=".7">FAN-MADE • ORIGINAL ART</text></svg>`,
  'f1-kimi-antonelli.svg': `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="600" viewBox="0 0 600 600"><rect x="18" y="18" width="564" height="564" rx="52" fill="#f8f6f0" stroke="#00a19b" stroke-width="10"/><path d="M85 150 L515 150 L470 220 L130 220Z" fill="#00a19b" opacity=".13"/><path d="M100 260 L500 260" stroke="#00a19b" stroke-width="8" stroke-linecap="round" opacity=".5"/><circle cx="300" cy="205" r="72" fill="#00a19b" opacity=".12"/><path d="M260 165 L340 165 L365 195 L340 225 L260 225 L235 195Z" fill="#00a19b"/><path d="M275 174 L325 174 L339 194 L325 214 L275 214 L261 194Z" fill="#f8f6f0" opacity=".9"/><path d="M130 465 L470 465" stroke="#00a19b" stroke-width="5" stroke-linecap="round" opacity=".45"/><text x="300" y="385" text-anchor="middle" font-family="Arial,sans-serif" font-size="43" font-weight="900" letter-spacing="1" fill="#00a19b">KIMI ANTONELLI</text><text x="300" y="500" text-anchor="middle" font-family="Arial,sans-serif" font-size="24" font-weight="800" letter-spacing="5" fill="#00a19b">RACE WEEKEND</text><text x="300" y="540" text-anchor="middle" font-family="Arial,sans-serif" font-size="16" font-weight="700" letter-spacing="4" fill="#00a19b" opacity=".7">FAN-MADE • ORIGINAL ART</text></svg>`,
  'f1-charles-leclerc.svg': `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="600" viewBox="0 0 600 600"><rect x="18" y="18" width="564" height="564" rx="52" fill="#f8f6f0" stroke="#e73535" stroke-width="10"/><path d="M85 150 L515 150 L470 220 L130 220Z" fill="#e73535" opacity=".13"/><path d="M100 260 L500 260" stroke="#e73535" stroke-width="8" stroke-linecap="round" opacity=".5"/><circle cx="300" cy="205" r="72" fill="#e73535" opacity=".12"/><path d="M260 165 L340 165 L365 195 L340 225 L260 225 L235 195Z" fill="#e73535"/><path d="M275 174 L325 174 L339 194 L325 214 L275 214 L261 194Z" fill="#f8f6f0" opacity=".9"/><path d="M130 465 L470 465" stroke="#e73535" stroke-width="5" stroke-linecap="round" opacity=".45"/><text x="300" y="385" text-anchor="middle" font-family="Arial,sans-serif" font-size="43" font-weight="900" letter-spacing="1" fill="#e73535">CHARLES LECLERC</text><text x="300" y="500" text-anchor="middle" font-family="Arial,sans-serif" font-size="24" font-weight="800" letter-spacing="5" fill="#e73535">RACE WEEKEND</text><text x="300" y="540" text-anchor="middle" font-family="Arial,sans-serif" font-size="16" font-weight="700" letter-spacing="4" fill="#e73535" opacity=".7">FAN-MADE • ORIGINAL ART</text></svg>`,
  'f1-lewis-hamilton.svg': `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="600" viewBox="0 0 600 600"><rect x="18" y="18" width="564" height="564" rx="52" fill="#f8f6f0" stroke="#e73535" stroke-width="10"/><path d="M85 150 L515 150 L470 220 L130 220Z" fill="#e73535" opacity=".13"/><path d="M100 260 L500 260" stroke="#e73535" stroke-width="8" stroke-linecap="round" opacity=".5"/><circle cx="300" cy="205" r="72" fill="#e73535" opacity=".12"/><path d="M260 165 L340 165 L365 195 L340 225 L260 225 L235 195Z" fill="#e73535"/><path d="M275 174 L325 174 L339 194 L325 214 L275 214 L261 194Z" fill="#f8f6f0" opacity=".9"/><path d="M130 465 L470 465" stroke="#e73535" stroke-width="5" stroke-linecap="round" opacity=".45"/><text x="300" y="385" text-anchor="middle" font-family="Arial,sans-serif" font-size="43" font-weight="900" letter-spacing="1" fill="#e73535">LEWIS HAMILTON</text><text x="300" y="500" text-anchor="middle" font-family="Arial,sans-serif" font-size="24" font-weight="800" letter-spacing="5" fill="#e73535">RACE WEEKEND</text><text x="300" y="540" text-anchor="middle" font-family="Arial,sans-serif" font-size="16" font-weight="700" letter-spacing="4" fill="#e73535" opacity=".7">FAN-MADE • ORIGINAL ART</text></svg>`,
  'f1-lando-norris.svg': `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="600" viewBox="0 0 600 600"><rect x="18" y="18" width="564" height="564" rx="52" fill="#f8f6f0" stroke="#ff8a20" stroke-width="10"/><path d="M85 150 L515 150 L470 220 L130 220Z" fill="#ff8a20" opacity=".13"/><path d="M100 260 L500 260" stroke="#ff8a20" stroke-width="8" stroke-linecap="round" opacity=".5"/><circle cx="300" cy="205" r="72" fill="#ff8a20" opacity=".12"/><path d="M260 165 L340 165 L365 195 L340 225 L260 225 L235 195Z" fill="#ff8a20"/><path d="M275 174 L325 174 L339 194 L325 214 L275 214 L261 194Z" fill="#f8f6f0" opacity=".9"/><path d="M130 465 L470 465" stroke="#ff8a20" stroke-width="5" stroke-linecap="round" opacity=".45"/><text x="300" y="385" text-anchor="middle" font-family="Arial,sans-serif" font-size="43" font-weight="900" letter-spacing="1" fill="#ff8a20">LANDO NORRIS</text><text x="300" y="500" text-anchor="middle" font-family="Arial,sans-serif" font-size="24" font-weight="800" letter-spacing="5" fill="#ff8a20">RACE WEEKEND</text><text x="300" y="540" text-anchor="middle" font-family="Arial,sans-serif" font-size="16" font-weight="700" letter-spacing="4" fill="#ff8a20" opacity=".7">FAN-MADE • ORIGINAL ART</text></svg>`,
  'f1-oscar-piastri.svg': `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="600" viewBox="0 0 600 600"><rect x="18" y="18" width="564" height="564" rx="52" fill="#f8f6f0" stroke="#ff8a20" stroke-width="10"/><path d="M85 150 L515 150 L470 220 L130 220Z" fill="#ff8a20" opacity=".13"/><path d="M100 260 L500 260" stroke="#ff8a20" stroke-width="8" stroke-linecap="round" opacity=".5"/><circle cx="300" cy="205" r="72" fill="#ff8a20" opacity=".12"/><path d="M260 165 L340 165 L365 195 L340 225 L260 225 L235 195Z" fill="#ff8a20"/><path d="M275 174 L325 174 L339 194 L325 214 L275 214 L261 194Z" fill="#f8f6f0" opacity=".9"/><path d="M130 465 L470 465" stroke="#ff8a20" stroke-width="5" stroke-linecap="round" opacity=".45"/><text x="300" y="385" text-anchor="middle" font-family="Arial,sans-serif" font-size="43" font-weight="900" letter-spacing="1" fill="#ff8a20">OSCAR PIASTRI</text><text x="300" y="500" text-anchor="middle" font-family="Arial,sans-serif" font-size="24" font-weight="800" letter-spacing="5" fill="#ff8a20">RACE WEEKEND</text><text x="300" y="540" text-anchor="middle" font-family="Arial,sans-serif" font-size="16" font-weight="700" letter-spacing="4" fill="#ff8a20" opacity=".7">FAN-MADE • ORIGINAL ART</text></svg>`,
  'f1-max-verstappen.svg': `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="600" viewBox="0 0 600 600"><rect x="18" y="18" width="564" height="564" rx="52" fill="#f8f6f0" stroke="#2448a5" stroke-width="10"/><path d="M85 150 L515 150 L470 220 L130 220Z" fill="#2448a5" opacity=".13"/><path d="M100 260 L500 260" stroke="#2448a5" stroke-width="8" stroke-linecap="round" opacity=".5"/><circle cx="300" cy="205" r="72" fill="#2448a5" opacity=".12"/><path d="M260 165 L340 165 L365 195 L340 225 L260 225 L235 195Z" fill="#2448a5"/><path d="M275 174 L325 174 L339 194 L325 214 L275 214 L261 194Z" fill="#f8f6f0" opacity=".9"/><path d="M130 465 L470 465" stroke="#2448a5" stroke-width="5" stroke-linecap="round" opacity=".45"/><text x="300" y="385" text-anchor="middle" font-family="Arial,sans-serif" font-size="43" font-weight="900" letter-spacing="1" fill="#2448a5">MAX VERSTAPPEN</text><text x="300" y="500" text-anchor="middle" font-family="Arial,sans-serif" font-size="24" font-weight="800" letter-spacing="5" fill="#2448a5">RACE WEEKEND</text><text x="300" y="540" text-anchor="middle" font-family="Arial,sans-serif" font-size="16" font-weight="700" letter-spacing="4" fill="#2448a5" opacity=".7">FAN-MADE • ORIGINAL ART</text></svg>`,
  'f1-isack-hadjar.svg': `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="600" viewBox="0 0 600 600"><rect x="18" y="18" width="564" height="564" rx="52" fill="#f8f6f0" stroke="#2448a5" stroke-width="10"/><path d="M85 150 L515 150 L470 220 L130 220Z" fill="#2448a5" opacity=".13"/><path d="M100 260 L500 260" stroke="#2448a5" stroke-width="8" stroke-linecap="round" opacity=".5"/><circle cx="300" cy="205" r="72" fill="#2448a5" opacity=".12"/><path d="M260 165 L340 165 L365 195 L340 225 L260 225 L235 195Z" fill="#2448a5"/><path d="M275 174 L325 174 L339 194 L325 214 L275 214 L261 194Z" fill="#f8f6f0" opacity=".9"/><path d="M130 465 L470 465" stroke="#2448a5" stroke-width="5" stroke-linecap="round" opacity=".45"/><text x="300" y="385" text-anchor="middle" font-family="Arial,sans-serif" font-size="43" font-weight="900" letter-spacing="1" fill="#2448a5">ISACK HADJAR</text><text x="300" y="500" text-anchor="middle" font-family="Arial,sans-serif" font-size="24" font-weight="800" letter-spacing="5" fill="#2448a5">RACE WEEKEND</text><text x="300" y="540" text-anchor="middle" font-family="Arial,sans-serif" font-size="16" font-weight="700" letter-spacing="4" fill="#2448a5" opacity=".7">FAN-MADE • ORIGINAL ART</text></svg>`,
  'f1-liam-lawson.svg': `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="600" viewBox="0 0 600 600"><rect x="18" y="18" width="564" height="564" rx="52" fill="#f8f6f0" stroke="#5b82c7" stroke-width="10"/><path d="M85 150 L515 150 L470 220 L130 220Z" fill="#5b82c7" opacity=".13"/><path d="M100 260 L500 260" stroke="#5b82c7" stroke-width="8" stroke-linecap="round" opacity=".5"/><circle cx="300" cy="205" r="72" fill="#5b82c7" opacity=".12"/><path d="M260 165 L340 165 L365 195 L340 225 L260 225 L235 195Z" fill="#5b82c7"/><path d="M275 174 L325 174 L339 194 L325 214 L275 214 L261 194Z" fill="#f8f6f0" opacity=".9"/><path d="M130 465 L470 465" stroke="#5b82c7" stroke-width="5" stroke-linecap="round" opacity=".45"/><text x="300" y="385" text-anchor="middle" font-family="Arial,sans-serif" font-size="43" font-weight="900" letter-spacing="1" fill="#5b82c7">LIAM LAWSON</text><text x="300" y="500" text-anchor="middle" font-family="Arial,sans-serif" font-size="24" font-weight="800" letter-spacing="5" fill="#5b82c7">RACE WEEKEND</text><text x="300" y="540" text-anchor="middle" font-family="Arial,sans-serif" font-size="16" font-weight="700" letter-spacing="4" fill="#5b82c7" opacity=".7">FAN-MADE • ORIGINAL ART</text></svg>`,
  'f1-arvid-lindblad.svg': `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="600" viewBox="0 0 600 600"><rect x="18" y="18" width="564" height="564" rx="52" fill="#f8f6f0" stroke="#5b82c7" stroke-width="10"/><path d="M85 150 L515 150 L470 220 L130 220Z" fill="#5b82c7" opacity=".13"/><path d="M100 260 L500 260" stroke="#5b82c7" stroke-width="8" stroke-linecap="round" opacity=".5"/><circle cx="300" cy="205" r="72" fill="#5b82c7" opacity=".12"/><path d="M260 165 L340 165 L365 195 L340 225 L260 225 L235 195Z" fill="#5b82c7"/><path d="M275 174 L325 174 L339 194 L325 214 L275 214 L261 194Z" fill="#f8f6f0" opacity=".9"/><path d="M130 465 L470 465" stroke="#5b82c7" stroke-width="5" stroke-linecap="round" opacity=".45"/><text x="300" y="385" text-anchor="middle" font-family="Arial,sans-serif" font-size="43" font-weight="900" letter-spacing="1" fill="#5b82c7">ARVID LINDBLAD</text><text x="300" y="500" text-anchor="middle" font-family="Arial,sans-serif" font-size="24" font-weight="800" letter-spacing="5" fill="#5b82c7">RACE WEEKEND</text><text x="300" y="540" text-anchor="middle" font-family="Arial,sans-serif" font-size="16" font-weight="700" letter-spacing="4" fill="#5b82c7" opacity=".7">FAN-MADE • ORIGINAL ART</text></svg>`,
  'f1-pierre-gasly.svg': `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="600" viewBox="0 0 600 600"><rect x="18" y="18" width="564" height="564" rx="52" fill="#f8f6f0" stroke="#3972d8" stroke-width="10"/><path d="M85 150 L515 150 L470 220 L130 220Z" fill="#3972d8" opacity=".13"/><path d="M100 260 L500 260" stroke="#3972d8" stroke-width="8" stroke-linecap="round" opacity=".5"/><circle cx="300" cy="205" r="72" fill="#3972d8" opacity=".12"/><path d="M260 165 L340 165 L365 195 L340 225 L260 225 L235 195Z" fill="#3972d8"/><path d="M275 174 L325 174 L339 194 L325 214 L275 214 L261 194Z" fill="#f8f6f0" opacity=".9"/><path d="M130 465 L470 465" stroke="#3972d8" stroke-width="5" stroke-linecap="round" opacity=".45"/><text x="300" y="385" text-anchor="middle" font-family="Arial,sans-serif" font-size="43" font-weight="900" letter-spacing="1" fill="#3972d8">PIERRE GASLY</text><text x="300" y="500" text-anchor="middle" font-family="Arial,sans-serif" font-size="24" font-weight="800" letter-spacing="5" fill="#3972d8">RACE WEEKEND</text><text x="300" y="540" text-anchor="middle" font-family="Arial,sans-serif" font-size="16" font-weight="700" letter-spacing="4" fill="#3972d8" opacity=".7">FAN-MADE • ORIGINAL ART</text></svg>`,
  'f1-franco-colapinto.svg': `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="600" viewBox="0 0 600 600"><rect x="18" y="18" width="564" height="564" rx="52" fill="#f8f6f0" stroke="#3972d8" stroke-width="10"/><path d="M85 150 L515 150 L470 220 L130 220Z" fill="#3972d8" opacity=".13"/><path d="M100 260 L500 260" stroke="#3972d8" stroke-width="8" stroke-linecap="round" opacity=".5"/><circle cx="300" cy="205" r="72" fill="#3972d8" opacity=".12"/><path d="M260 165 L340 165 L365 195 L340 225 L260 225 L235 195Z" fill="#3972d8"/><path d="M275 174 L325 174 L339 194 L325 214 L275 214 L261 194Z" fill="#f8f6f0" opacity=".9"/><path d="M130 465 L470 465" stroke="#3972d8" stroke-width="5" stroke-linecap="round" opacity=".45"/><text x="300" y="355" text-anchor="middle" font-family="Arial,sans-serif" font-size="44" font-weight="900" letter-spacing="1" fill="#3972d8">FRANCO</text><text x="300" y="410" text-anchor="middle" font-family="Arial,sans-serif" font-size="40" font-weight="900" letter-spacing="1" fill="#3972d8">COLAPINTO</text><text x="300" y="500" text-anchor="middle" font-family="Arial,sans-serif" font-size="24" font-weight="800" letter-spacing="5" fill="#3972d8">RACE WEEKEND</text><text x="300" y="540" text-anchor="middle" font-family="Arial,sans-serif" font-size="16" font-weight="700" letter-spacing="4" fill="#3972d8" opacity=".7">FAN-MADE • ORIGINAL ART</text></svg>`,
  'f1-esteban-ocon.svg': `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="600" viewBox="0 0 600 600"><rect x="18" y="18" width="564" height="564" rx="52" fill="#f8f6f0" stroke="#c5d1db" stroke-width="10"/><path d="M85 150 L515 150 L470 220 L130 220Z" fill="#c5d1db" opacity=".13"/><path d="M100 260 L500 260" stroke="#c5d1db" stroke-width="8" stroke-linecap="round" opacity=".5"/><circle cx="300" cy="205" r="72" fill="#c5d1db" opacity=".12"/><path d="M260 165 L340 165 L365 195 L340 225 L260 225 L235 195Z" fill="#c5d1db"/><path d="M275 174 L325 174 L339 194 L325 214 L275 214 L261 194Z" fill="#f8f6f0" opacity=".9"/><path d="M130 465 L470 465" stroke="#c5d1db" stroke-width="5" stroke-linecap="round" opacity=".45"/><text x="300" y="385" text-anchor="middle" font-family="Arial,sans-serif" font-size="43" font-weight="900" letter-spacing="1" fill="#c5d1db">ESTEBAN OCON</text><text x="300" y="500" text-anchor="middle" font-family="Arial,sans-serif" font-size="24" font-weight="800" letter-spacing="5" fill="#c5d1db">RACE WEEKEND</text><text x="300" y="540" text-anchor="middle" font-family="Arial,sans-serif" font-size="16" font-weight="700" letter-spacing="4" fill="#c5d1db" opacity=".7">FAN-MADE • ORIGINAL ART</text></svg>`,
  'f1-oliver-bearman.svg': `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="600" viewBox="0 0 600 600"><rect x="18" y="18" width="564" height="564" rx="52" fill="#f8f6f0" stroke="#c5d1db" stroke-width="10"/><path d="M85 150 L515 150 L470 220 L130 220Z" fill="#c5d1db" opacity=".13"/><path d="M100 260 L500 260" stroke="#c5d1db" stroke-width="8" stroke-linecap="round" opacity=".5"/><circle cx="300" cy="205" r="72" fill="#c5d1db" opacity=".12"/><path d="M260 165 L340 165 L365 195 L340 225 L260 225 L235 195Z" fill="#c5d1db"/><path d="M275 174 L325 174 L339 194 L325 214 L275 214 L261 194Z" fill="#f8f6f0" opacity=".9"/><path d="M130 465 L470 465" stroke="#c5d1db" stroke-width="5" stroke-linecap="round" opacity=".45"/><text x="300" y="385" text-anchor="middle" font-family="Arial,sans-serif" font-size="43" font-weight="900" letter-spacing="1" fill="#c5d1db">OLIVER BEARMAN</text><text x="300" y="500" text-anchor="middle" font-family="Arial,sans-serif" font-size="24" font-weight="800" letter-spacing="5" fill="#c5d1db">RACE WEEKEND</text><text x="300" y="540" text-anchor="middle" font-family="Arial,sans-serif" font-size="16" font-weight="700" letter-spacing="4" fill="#c5d1db" opacity=".7">FAN-MADE • ORIGINAL ART</text></svg>`,
  'f1-nico-hulkenberg.svg': `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="600" viewBox="0 0 600 600"><rect x="18" y="18" width="564" height="564" rx="52" fill="#f8f6f0" stroke="#d31e30" stroke-width="10"/><path d="M85 150 L515 150 L470 220 L130 220Z" fill="#d31e30" opacity=".13"/><path d="M100 260 L500 260" stroke="#d31e30" stroke-width="8" stroke-linecap="round" opacity=".5"/><circle cx="300" cy="205" r="72" fill="#d31e30" opacity=".12"/><path d="M260 165 L340 165 L365 195 L340 225 L260 225 L235 195Z" fill="#d31e30"/><path d="M275 174 L325 174 L339 194 L325 214 L275 214 L261 194Z" fill="#f8f6f0" opacity=".9"/><path d="M130 465 L470 465" stroke="#d31e30" stroke-width="5" stroke-linecap="round" opacity=".45"/><text x="300" y="385" text-anchor="middle" font-family="Arial,sans-serif" font-size="43" font-weight="900" letter-spacing="1" fill="#d31e30">NICO HULKENBERG</text><text x="300" y="500" text-anchor="middle" font-family="Arial,sans-serif" font-size="24" font-weight="800" letter-spacing="5" fill="#d31e30">RACE WEEKEND</text><text x="300" y="540" text-anchor="middle" font-family="Arial,sans-serif" font-size="16" font-weight="700" letter-spacing="4" fill="#d31e30" opacity=".7">FAN-MADE • ORIGINAL ART</text></svg>`,
  'f1-gabriel-bortoleto.svg': `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="600" viewBox="0 0 600 600"><rect x="18" y="18" width="564" height="564" rx="52" fill="#f8f6f0" stroke="#d31e30" stroke-width="10"/><path d="M85 150 L515 150 L470 220 L130 220Z" fill="#d31e30" opacity=".13"/><path d="M100 260 L500 260" stroke="#d31e30" stroke-width="8" stroke-linecap="round" opacity=".5"/><circle cx="300" cy="205" r="72" fill="#d31e30" opacity=".12"/><path d="M260 165 L340 165 L365 195 L340 225 L260 225 L235 195Z" fill="#d31e30"/><path d="M275 174 L325 174 L339 194 L325 214 L275 214 L261 194Z" fill="#f8f6f0" opacity=".9"/><path d="M130 465 L470 465" stroke="#d31e30" stroke-width="5" stroke-linecap="round" opacity=".45"/><text x="300" y="355" text-anchor="middle" font-family="Arial,sans-serif" font-size="44" font-weight="900" letter-spacing="1" fill="#d31e30">GABRIEL</text><text x="300" y="410" text-anchor="middle" font-family="Arial,sans-serif" font-size="40" font-weight="900" letter-spacing="1" fill="#d31e30">BORTOLETO</text><text x="300" y="500" text-anchor="middle" font-family="Arial,sans-serif" font-size="24" font-weight="800" letter-spacing="5" fill="#d31e30">RACE WEEKEND</text><text x="300" y="540" text-anchor="middle" font-family="Arial,sans-serif" font-size="16" font-weight="700" letter-spacing="4" fill="#d31e30" opacity=".7">FAN-MADE • ORIGINAL ART</text></svg>`,
  'f1-carlos-sainz.svg': `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="600" viewBox="0 0 600 600"><rect x="18" y="18" width="564" height="564" rx="52" fill="#f8f6f0" stroke="#2875d0" stroke-width="10"/><path d="M85 150 L515 150 L470 220 L130 220Z" fill="#2875d0" opacity=".13"/><path d="M100 260 L500 260" stroke="#2875d0" stroke-width="8" stroke-linecap="round" opacity=".5"/><circle cx="300" cy="205" r="72" fill="#2875d0" opacity=".12"/><path d="M260 165 L340 165 L365 195 L340 225 L260 225 L235 195Z" fill="#2875d0"/><path d="M275 174 L325 174 L339 194 L325 214 L275 214 L261 194Z" fill="#f8f6f0" opacity=".9"/><path d="M130 465 L470 465" stroke="#2875d0" stroke-width="5" stroke-linecap="round" opacity=".45"/><text x="300" y="385" text-anchor="middle" font-family="Arial,sans-serif" font-size="43" font-weight="900" letter-spacing="1" fill="#2875d0">CARLOS SAINZ</text><text x="300" y="500" text-anchor="middle" font-family="Arial,sans-serif" font-size="24" font-weight="800" letter-spacing="5" fill="#2875d0">RACE WEEKEND</text><text x="300" y="540" text-anchor="middle" font-family="Arial,sans-serif" font-size="16" font-weight="700" letter-spacing="4" fill="#2875d0" opacity=".7">FAN-MADE • ORIGINAL ART</text></svg>`,
  'f1-alexander-albon.svg': `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="600" viewBox="0 0 600 600"><rect x="18" y="18" width="564" height="564" rx="52" fill="#f8f6f0" stroke="#2875d0" stroke-width="10"/><path d="M85 150 L515 150 L470 220 L130 220Z" fill="#2875d0" opacity=".13"/><path d="M100 260 L500 260" stroke="#2875d0" stroke-width="8" stroke-linecap="round" opacity=".5"/><circle cx="300" cy="205" r="72" fill="#2875d0" opacity=".12"/><path d="M260 165 L340 165 L365 195 L340 225 L260 225 L235 195Z" fill="#2875d0"/><path d="M275 174 L325 174 L339 194 L325 214 L275 214 L261 194Z" fill="#f8f6f0" opacity=".9"/><path d="M130 465 L470 465" stroke="#2875d0" stroke-width="5" stroke-linecap="round" opacity=".45"/><text x="300" y="385" text-anchor="middle" font-family="Arial,sans-serif" font-size="43" font-weight="900" letter-spacing="1" fill="#2875d0">ALEXANDER ALBON</text><text x="300" y="500" text-anchor="middle" font-family="Arial,sans-serif" font-size="24" font-weight="800" letter-spacing="5" fill="#2875d0">RACE WEEKEND</text><text x="300" y="540" text-anchor="middle" font-family="Arial,sans-serif" font-size="16" font-weight="700" letter-spacing="4" fill="#2875d0" opacity=".7">FAN-MADE • ORIGINAL ART</text></svg>`,
  'f1-fernando-alonso.svg': `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="600" viewBox="0 0 600 600"><rect x="18" y="18" width="564" height="564" rx="52" fill="#f8f6f0" stroke="#5cae63" stroke-width="10"/><path d="M85 150 L515 150 L470 220 L130 220Z" fill="#5cae63" opacity=".13"/><path d="M100 260 L500 260" stroke="#5cae63" stroke-width="8" stroke-linecap="round" opacity=".5"/><circle cx="300" cy="205" r="72" fill="#5cae63" opacity=".12"/><path d="M260 165 L340 165 L365 195 L340 225 L260 225 L235 195Z" fill="#5cae63"/><path d="M275 174 L325 174 L339 194 L325 214 L275 214 L261 194Z" fill="#f8f6f0" opacity=".9"/><path d="M130 465 L470 465" stroke="#5cae63" stroke-width="5" stroke-linecap="round" opacity=".45"/><text x="300" y="385" text-anchor="middle" font-family="Arial,sans-serif" font-size="43" font-weight="900" letter-spacing="1" fill="#5cae63">FERNANDO ALONSO</text><text x="300" y="500" text-anchor="middle" font-family="Arial,sans-serif" font-size="24" font-weight="800" letter-spacing="5" fill="#5cae63">RACE WEEKEND</text><text x="300" y="540" text-anchor="middle" font-family="Arial,sans-serif" font-size="16" font-weight="700" letter-spacing="4" fill="#5cae63" opacity=".7">FAN-MADE • ORIGINAL ART</text></svg>`,
  'f1-lance-stroll.svg': `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="600" viewBox="0 0 600 600"><rect x="18" y="18" width="564" height="564" rx="52" fill="#f8f6f0" stroke="#5cae63" stroke-width="10"/><path d="M85 150 L515 150 L470 220 L130 220Z" fill="#5cae63" opacity=".13"/><path d="M100 260 L500 260" stroke="#5cae63" stroke-width="8" stroke-linecap="round" opacity=".5"/><circle cx="300" cy="205" r="72" fill="#5cae63" opacity=".12"/><path d="M260 165 L340 165 L365 195 L340 225 L260 225 L235 195Z" fill="#5cae63"/><path d="M275 174 L325 174 L339 194 L325 214 L275 214 L261 194Z" fill="#f8f6f0" opacity=".9"/><path d="M130 465 L470 465" stroke="#5cae63" stroke-width="5" stroke-linecap="round" opacity=".45"/><text x="300" y="385" text-anchor="middle" font-family="Arial,sans-serif" font-size="43" font-weight="900" letter-spacing="1" fill="#5cae63">LANCE STROLL</text><text x="300" y="500" text-anchor="middle" font-family="Arial,sans-serif" font-size="24" font-weight="800" letter-spacing="5" fill="#5cae63">RACE WEEKEND</text><text x="300" y="540" text-anchor="middle" font-family="Arial,sans-serif" font-size="16" font-weight="700" letter-spacing="4" fill="#5cae63" opacity=".7">FAN-MADE • ORIGINAL ART</text></svg>`,
  'f1-sergio-perez.svg': `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="600" viewBox="0 0 600 600"><rect x="18" y="18" width="564" height="564" rx="52" fill="#f8f6f0" stroke="#2454aa" stroke-width="10"/><path d="M85 150 L515 150 L470 220 L130 220Z" fill="#2454aa" opacity=".13"/><path d="M100 260 L500 260" stroke="#2454aa" stroke-width="8" stroke-linecap="round" opacity=".5"/><circle cx="300" cy="205" r="72" fill="#2454aa" opacity=".12"/><path d="M260 165 L340 165 L365 195 L340 225 L260 225 L235 195Z" fill="#2454aa"/><path d="M275 174 L325 174 L339 194 L325 214 L275 214 L261 194Z" fill="#f8f6f0" opacity=".9"/><path d="M130 465 L470 465" stroke="#2454aa" stroke-width="5" stroke-linecap="round" opacity=".45"/><text x="300" y="385" text-anchor="middle" font-family="Arial,sans-serif" font-size="43" font-weight="900" letter-spacing="1" fill="#2454aa">SERGIO PEREZ</text><text x="300" y="500" text-anchor="middle" font-family="Arial,sans-serif" font-size="24" font-weight="800" letter-spacing="5" fill="#2454aa">RACE WEEKEND</text><text x="300" y="540" text-anchor="middle" font-family="Arial,sans-serif" font-size="16" font-weight="700" letter-spacing="4" fill="#2454aa" opacity=".7">FAN-MADE • ORIGINAL ART</text></svg>`,
  'f1-valtteri-bottas.svg': `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="600" viewBox="0 0 600 600"><rect x="18" y="18" width="564" height="564" rx="52" fill="#f8f6f0" stroke="#2454aa" stroke-width="10"/><path d="M85 150 L515 150 L470 220 L130 220Z" fill="#2454aa" opacity=".13"/><path d="M100 260 L500 260" stroke="#2454aa" stroke-width="8" stroke-linecap="round" opacity=".5"/><circle cx="300" cy="205" r="72" fill="#2454aa" opacity=".12"/><path d="M260 165 L340 165 L365 195 L340 225 L260 225 L235 195Z" fill="#2454aa"/><path d="M275 174 L325 174 L339 194 L325 214 L275 214 L261 194Z" fill="#f8f6f0" opacity=".9"/><path d="M130 465 L470 465" stroke="#2454aa" stroke-width="5" stroke-linecap="round" opacity=".45"/><text x="300" y="385" text-anchor="middle" font-family="Arial,sans-serif" font-size="43" font-weight="900" letter-spacing="1" fill="#2454aa">VALTTERI BOTTAS</text><text x="300" y="500" text-anchor="middle" font-family="Arial,sans-serif" font-size="24" font-weight="800" letter-spacing="5" fill="#2454aa">RACE WEEKEND</text><text x="300" y="540" text-anchor="middle" font-family="Arial,sans-serif" font-size="16" font-weight="700" letter-spacing="4" fill="#2454aa" opacity=".7">FAN-MADE • ORIGINAL ART</text></svg>`,
};

document.querySelectorAll('[data-artwork]').forEach(el => {
  const artwork = svgDesigns[el.dataset.artwork];
  if (artwork) el.innerHTML = artwork;
});

const titles = {
  'good-vibes.svg': 'Good Vibes',
  'happy-flower.svg': 'Happy Flower',
  'stay-curious.svg': 'Stay Curious',
  'choose-kindness.svg': 'Choose Kindness',
  'tiny-happy.svg': 'Tiny Happy',
  'room-for-magic.svg': 'Room for Magic',
  'offline-mode.svg': 'Offline Mode',
  'little-lucky.svg': 'Little Lucky',
  'cr7-legend.svg': 'CR7: The Legend',
  'siuuu-energy.svg': 'SIUUU Energy',
  'number-seven.svg': 'Number 7',
  'portugal-pride.svg': 'Portugal Pride',
  'ronaldo-silhouette.svg': 'The Striker',
  'never-give-up.svg': 'Never Give Up',
  'messi-magic.svg': 'Messi Magic',
  'm10-goat.svg': 'M10 • GOAT Mode',
  'argentina-dream.svg': 'Argentina Dream',
  'the-playmaker.svg': 'The Playmaker',
  'football-is-life.svg': 'Football Is Life',
  'goat-debate.svg': 'GOAT Debate',
  'himym-suit-up.svg': 'Suit Up',
  'himym-yellow-umbrella.svg': 'Yellow Umbrella',
  'friends-central-perk.svg': 'Coffee & Friends',
  'friends-the-one.svg': 'The One With...',
  'modern-family-chaos.svg': 'Family Chaos Club',
  'modern-family-together.svg': 'Different Together',
  'big-bang-nerd-mode.svg': 'Nerd Mode',
  'big-bang-geek-chic.svg': 'Geek Chic',
  'office-worlds-okayest.svg': 'World’s Okayest Boss',
  'office-paper-company.svg': 'Paper Company Energy',
  'outer-banks-pogue-life.svg': 'Pogue Life',
  'outer-banks-treasure.svg': 'Treasure Coast',
  'wednesday-dark-academia.svg': 'Dark Academia',
  'wednesday-nevermore.svg': 'Nevermore Mood',
  'stranger-things-upside-down.svg': 'Upside Down Club',
  'stranger-things-night-lights.svg': 'Night Lights',
  'b99-nine-nine.svg': 'Nine-Nine!',
  'b99-cool-cool.svg': 'Cool Cool Cool',
  'vampire-diaries-mystic-falls.svg': 'Mystic Falls After Dark',
  'vampire-diaries-midnight.svg': 'Midnight Diaries',
  'f1-george-russell.svg': 'George Russell',
  'f1-kimi-antonelli.svg': 'Kimi Antonelli',
  'f1-charles-leclerc.svg': 'Charles Leclerc',
  'f1-lewis-hamilton.svg': 'Lewis Hamilton',
  'f1-lando-norris.svg': 'Lando Norris',
  'f1-oscar-piastri.svg': 'Oscar Piastri',
  'f1-max-verstappen.svg': 'Max Verstappen',
  'f1-isack-hadjar.svg': 'Isack Hadjar',
  'f1-liam-lawson.svg': 'Liam Lawson',
  'f1-arvid-lindblad.svg': 'Arvid Lindblad',
  'f1-pierre-gasly.svg': 'Pierre Gasly',
  'f1-franco-colapinto.svg': 'Franco Colapinto',
  'f1-esteban-ocon.svg': 'Esteban Ocon',
  'f1-oliver-bearman.svg': 'Oliver Bearman',
  'f1-nico-hulkenberg.svg': 'Nico Hulkenberg',
  'f1-gabriel-bortoleto.svg': 'Gabriel Bortoleto',
  'f1-carlos-sainz.svg': 'Carlos Sainz',
  'f1-alexander-albon.svg': 'Alexander Albon',
  'f1-fernando-alonso.svg': 'Fernando Alonso',
  'f1-lance-stroll.svg': 'Lance Stroll',
  'f1-sergio-perez.svg': 'Sergio Perez',
  'f1-valtteri-bottas.svg': 'Valtteri Bottas',
};
function downloadSVG(filename) {
  const svg = svgDesigns[filename];
  if (!svg) return;
  const blob = new Blob([svg], {type:'image/svg+xml;charset=utf-8'});
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
}
document.querySelectorAll('[data-download]').forEach(button => button.addEventListener('click', () => downloadSVG(button.dataset.download)));

const modal = document.getElementById('previewModal');
const modalArtwork = document.getElementById('modalArtwork');
const modalTitle = document.getElementById('modalTitle');
const modalDownload = document.getElementById('modalDownload');
let currentFile = 'good-vibes.svg';
function openPreview(filename) {
  currentFile = filename;
  modalTitle.textContent = titles[filename] || 'Sticker design';
  modalArtwork.innerHTML = svgDesigns[filename] || '';
  modalDownload.onclick = () => downloadSVG(currentFile);
  modal.classList.add('open');
  modal.setAttribute('aria-hidden','false');
  document.body.style.overflow = 'hidden';
}
function closePreview() {
  modal.classList.remove('open');
  modal.setAttribute('aria-hidden','true');
  document.body.style.overflow = '';
}
document.querySelectorAll('[data-preview]').forEach(button => button.addEventListener('click', () => openPreview(button.dataset.preview)));
document.querySelectorAll('[data-close-modal]').forEach(button => button.addEventListener('click', closePreview));
document.addEventListener('keydown', event => { if (event.key === 'Escape') closePreview(); });


// Order request flow. Requires the included Node server for secure storage and manual payment verification.
const orderForm = document.getElementById('orderForm');
const quantityInput = orderForm?.elements.namedItem('quantity');
const orderTotal = document.getElementById('orderTotal');
const orderStatus = document.getElementById('orderStatus');
const copyOrderButton = document.getElementById('copyOrder');
let preparedOrderText = '';
function updateOrderTotal() {
  const quantity = Math.max(1, Number.parseInt(quantityInput.value, 10) || 1);
  quantityInput.value = quantity;
  orderTotal.textContent = `₹${(399 * quantity).toLocaleString('en-IN')}`;
}
quantityInput?.addEventListener('input', updateOrderTotal);
orderForm?.addEventListener('submit', async event => {
  event.preventDefault();
  const data = new FormData(orderForm);
  const designs = String(data.get('designs') || '').trim();
  const chosen = designs.split(/[\n,;]/).map(item => item.trim()).filter(Boolean);
  const category = String(data.get('category') || '');
  const categoryFiles = {
    f1: Object.keys(titles).filter(file => file.startsWith('f1-')),
    football: ['cr7-legend.svg','siuuu-energy.svg','number-seven.svg','portugal-pride.svg','ronaldo-silhouette.svg','never-give-up.svg','messi-magic.svg','m10-goat.svg','argentina-dream.svg','the-playmaker.svg','football-is-life.svg','goat-debate.svg'],
    tv: Object.keys(titles).filter(file => /^(himym-|friends-|modern-family-|big-bang-|office-|outer-banks-|wednesday-|stranger-things-|b99-|vampire-diaries-)/.test(file)),
    everyday: ['good-vibes.svg','happy-flower.svg','stay-curious.svg','choose-kindness.svg','tiny-happy.svg','room-for-magic.svg','offline-mode.svg','little-lucky.svg']
  };
  const allowedTitles = (categoryFiles[category] || []).map(file => (titles[file] || '').toLowerCase());
  if (chosen.length !== 6 || chosen.some(item => !allowedTitles.includes(item.toLowerCase()))) {
    orderStatus.className = 'order-status error';
    orderStatus.textContent = 'Please enter exactly 6 sticker titles from the single category you selected. Use the exact titles shown in the gallery.';
    copyOrderButton.hidden = true;
    return;
  }
  const address = String(data.get('address') || '').trim();
  if (!/(^|\D)\d{6}(\D|$)/.test(address)) {
    orderStatus.className = 'order-status error';
    orderStatus.textContent = 'Please include a valid 6-digit Indian PIN code in your delivery address.';
    return;
  }
  const payload = {
    customerName: String(data.get('customerName') || '').trim(),
    email: String(data.get('email') || '').trim(),
    phone: String(data.get('phone') || '').trim(),
    quantity: Math.max(1, Number.parseInt(data.get('quantity'), 10) || 1),
    category,
    designs: chosen,
    address,
    utr: String(data.get('utr') || '').trim()
  };
  orderStatus.className = 'order-status';
  orderStatus.textContent = 'Submitting your order request…';
  copyOrderButton.hidden = true;
  try {
    const response = await fetch('/api/orders', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(payload)});
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || 'Could not save your order.');
    preparedOrderText = `STICKER STUDIO ORDER REQUEST\nOrder ID: ${result.orderId}\nName: ${payload.customerName}\nEmail: ${payload.email}\nPhone: ${payload.phone}\nCategory: ${{f1:'Formula 1 (F1)',football:'Football',tv:'TV Shows',everyday:'Everyday / cute'}[category]}\nSets: ${payload.quantity}\nSticker designs per set: ${chosen.join(', ')}\nDelivery address in India: ${payload.address}\nUPI reference: ${payload.utr || 'Not provided'}\nTotal: ₹${(399*payload.quantity).toLocaleString('en-IN')}\nStatus: Pending manual payment verification`;
    orderStatus.className = 'order-status success';
    orderStatus.textContent = `Order request saved! Your order ID is ${result.orderId}. Pay ₹${(399*payload.quantity).toLocaleString('en-IN')} using the UPI QR, then keep your UPI transaction reference. Your order is not confirmed until the store owner verifies payment. Confirmation email will be sent to ${payload.email} after verification.`;
    copyOrderButton.hidden = false;
  } catch (error) {
    orderStatus.className = 'order-status error';
    orderStatus.textContent = error.message === 'Failed to fetch' ? 'The order server is not running or is not connected. Start the included server and open the website through http://localhost:3000.' : error.message;
  }
});
copyOrderButton?.addEventListener('click', async () => {
  if (!preparedOrderText) return;
  try { await navigator.clipboard.writeText(preparedOrderText); orderStatus.textContent += ' Order details copied.'; }
  catch { orderStatus.textContent = preparedOrderText; }
});
