const express = require('express');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const nodemailer = require('nodemailer');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const ROOT = __dirname;
const DATA_DIR = path.join(ROOT, 'data');
const ORDERS_FILE = path.join(DATA_DIR, 'orders.json');
const CATEGORY_LABELS = { f1: 'Formula 1 (F1)', football: 'Football', tv: 'TV Shows', everyday: 'Everyday / cute' };
const CATEGORY_TITLES = JSON.parse(fs.readFileSync(path.join(ROOT, 'catalog.json'), 'utf8'));
fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(ORDERS_FILE)) fs.writeFileSync(ORDERS_FILE, '[]', { mode: 0o600 });
app.use(express.json({ limit: '30kb' }));
app.use('/data', (req, res) => res.status(404).send('Not found'));
app.use(express.static(ROOT, { index: 'index.html', dotfiles: 'ignore' }));

function readOrders() { return JSON.parse(fs.readFileSync(ORDERS_FILE, 'utf8')); }
function writeOrders(orders) { fs.writeFileSync(ORDERS_FILE, JSON.stringify(orders, null, 2), { mode: 0o600 }); }
function clean(v, max = 500) { return String(v || '').trim().slice(0, max); }
function adminOnly(req, res, next) {
  const expected = process.env.ADMIN_PASSWORD;
  if (!expected || expected.length < 12) return res.status(503).json({ error: 'Set a strong ADMIN_PASSWORD (at least 12 characters) in your .env file first.' });
  const supplied = req.get('x-admin-password') || '';
  const a = Buffer.from(supplied); const b = Buffer.from(expected);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return res.status(401).json({ error: 'Incorrect admin password.' });
  next();
}
function mailer() {
  if (!process.env.SMTP_HOST || !process.env.SMTP_USER || !process.env.SMTP_PASS || !process.env.FROM_EMAIL) throw new Error('Email is not configured. Fill in SMTP settings in .env.');
  return nodemailer.createTransport({ host: process.env.SMTP_HOST, port: Number(process.env.SMTP_PORT || 587), secure: String(process.env.SMTP_SECURE || 'false') === 'true', auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS } });
}
async function sendConfirmation(order) {
  const transporter = mailer();
  await transporter.sendMail({
    from: process.env.FROM_EMAIL,
    to: order.email,
    subject: `Order confirmed — ${order.id}`,
    text: `Hi ${order.customerName},\n\nYour payment has been verified and your sticker order is confirmed.\n\nOrder ID: ${order.id}\nCategory: ${CATEGORY_LABELS[order.category]}\nSets: ${order.quantity}\nStickers per set: ${order.designs.join(', ')}\nTotal paid: ₹${order.total}\nDelivery address: ${order.address}\n\nWe will contact you with delivery updates. Delivery is within India only.\n\nThank you,\n${process.env.STORE_NAME || 'Laptop Stickers Download'}`
  });
}

app.post('/api/orders', (req, res) => {
  const body = req.body || {};
  const customerName = clean(body.customerName, 100), email = clean(body.email, 254), phone = clean(body.phone, 30);
  const address = clean(body.address, 1000), utr = clean(body.utr, 80), category = clean(body.category, 20);
  const quantity = Number.parseInt(body.quantity, 10);
  const designs = Array.isArray(body.designs) ? body.designs.map(x => clean(x, 100)) : [];
  if (!customerName || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || !phone) return res.status(400).json({ error: 'Please provide your name, a valid email address, and phone number.' });
  if (!CATEGORY_LABELS[category]) return res.status(400).json({ error: 'Please choose one valid sticker category.' });
  if (designs.length !== 6 || designs.some(x => !x)) return res.status(400).json({ error: 'Each set must contain exactly 6 sticker designs.' });
  const allowed = (CATEGORY_TITLES[category] || []).map(x => x.toLocaleLowerCase());
  if (designs.some(x => !allowed.includes(x.toLocaleLowerCase()))) return res.status(400).json({ error: 'All six designs must belong to the single category selected.' });
  if (!Number.isInteger(quantity) || quantity < 1 || quantity > 20) return res.status(400).json({ error: 'Quantity must be between 1 and 20 sets.' });
  if (!/(^|\D)\d{6}(\D|$)/.test(address)) return res.status(400).json({ error: 'Please include a valid 6-digit Indian PIN code in the delivery address.' });
  const orders = readOrders();
  const id = 'LS-' + crypto.randomBytes(4).toString('hex').toUpperCase();
  const order = { id, createdAt: new Date().toISOString(), customerName, email, phone, category, categoryLabel: CATEGORY_LABELS[category], quantity, designs, address, utr, total: quantity * 399, status: 'pending_payment_verification', emailSent: false };
  orders.push(order); writeOrders(orders);
  res.status(201).json({ orderId: id, total: order.total, status: order.status });
});

app.get('/api/admin/orders', adminOnly, (req, res) => {
  res.json(readOrders().map(({ id, createdAt, customerName, email, phone, category, categoryLabel, quantity, designs, address, utr, total, status, emailSent }) => ({ id, createdAt, customerName, email, phone, category, categoryLabel, quantity, designs, address, utr, total, status, emailSent })));
});
app.post('/api/admin/orders/:id/verify-payment', adminOnly, async (req, res) => {
  const orders = readOrders();
  const order = orders.find(o => o.id === req.params.id);
  if (!order) return res.status(404).json({ error: 'Order not found.' });
  if (order.status !== 'paid') { order.status = 'paid'; order.paidAt = new Date().toISOString(); order.adminNote = clean(req.body?.note, 300); }
  try {
    if (!order.emailSent) { await sendConfirmation(order); order.emailSent = true; order.emailSentAt = new Date().toISOString(); }
    writeOrders(orders);
    res.json({ ok: true, message: `Payment verified. Confirmation email sent to ${order.email}.` });
  } catch (err) {
    writeOrders(orders);
    res.status(502).json({ error: `Payment status saved as paid, but confirmation email failed: ${err.message}. Fix SMTP settings and click Send confirmation again.` });
  }
});
app.get('/admin', (req, res) => res.sendFile(path.join(ROOT, 'admin.html')));
app.listen(PORT, () => console.log(`Sticker store running at http://localhost:${PORT}`));
